package com.utcl.web.controller;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.utcl.Inf.VendorService;
import com.utcl.domain.Vendor;
import com.utcl.record.VendorARecord;

import jakarta.validation.Valid;

@RestController

public class VendorController {

	private VendorService vendorService;

	public VendorController(VendorService vendorService) {
		super();
		this.vendorService = vendorService;
	}

	@GetMapping(value = "/getVendor/{name}", produces = "application/json")
	public ResponseEntity<Object> getVendor(@Valid @PathVariable("name") String name) {
		try {
			// get RollObject from logged in user and pass roll object instead of "A"
			// also check overloaded method
			return ResponseEntity.ok(vendorService.getVendor(name, "A"));
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);// (vendorService.getVendor(name,
																							// "A")) ;
		}

	}

}
