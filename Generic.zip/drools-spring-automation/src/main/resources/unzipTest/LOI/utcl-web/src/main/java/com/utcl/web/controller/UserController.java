package com.utcl.web.controller;

import java.util.List;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.utcl.Inf.UserService;
import com.utcl.Inf.VendorService;
import com.utcl.domain.RoleObject;
import com.utcl.domain.User;
import com.utcl.record.UserRecord;

import jakarta.validation.Valid;

@RestController

public class UserController {
	
	
	
	private UserService userService;


	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}


	@PostMapping(value="/addUser",produces="application/json")
	public UserRecord addUser(UserRecord record) {		
		return userService.addUser(record);
	}
	
	@GetMapping(value="/getRoles",produces="application/json")
	public List<RoleObject> getRoles() {		
		return userService.getRoles();
	}
	@GetMapping(value="/getUsers",produces="application/json")
	public List<UserRecord> getUsers() {		
		return userService.getUsers();
	}

}
