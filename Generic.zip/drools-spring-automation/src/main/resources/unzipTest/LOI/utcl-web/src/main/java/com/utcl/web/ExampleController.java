package com.utcl.web;

import org.springframework.stereotype.Controller;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.DependsOn;
import org.springframework.http.ResponseEntity;

import com.utcl.Inf.VendorService;
import com.utcl.openapi.generated.api.ExampleApi;

@Controller
public class ExampleController implements ExampleApi {


	@Override
    public ResponseEntity<String> sayHelloToWorld() {
        return ResponseEntity.ok("Hello World");
    }

}
