package com.utcl.domain;

import com.fasterxml.jackson.databind.ObjectMapper;

public class MapperUtil {
	static ObjectMapper mapper = new ObjectMapper();
	public static Object getConvertedObject(Object fromValue, Class<?> toValueType) {
		return mapper.convertValue(fromValue, toValueType);
	}
}
