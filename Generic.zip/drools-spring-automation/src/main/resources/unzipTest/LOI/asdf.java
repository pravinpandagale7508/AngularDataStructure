import java.util.ArrayList;
import java.util.List;

import com.birlasoft.project.dto.MethodInfo;
import com.birlasoft.project.dto.MethodInfo.Parameter;

MethodInfo updateService = new MethodInfo("update" + request.className(), keywords, new ArrayList<String>());
			List<MethodInfo.Parameter> updateServiceParameter = new ArrayList<MethodInfo.Parameter>();
			
			List<String> updateParaAnnListSer = new ArrayList<String>();
			updateParaAnnListSer.add("RequestBody");
			List<String> updateParaImportList = new ArrayList<String>();
			updateParaImportList.add("org.springframework.web.bind.annotation.RequestBody");
			
			updateServiceParameter.add(new Parameter(request.className() + "Dto", request.className().toLowerCase(), updateParaImportList, updateParaAnnListSer));
			updateService.setParameters(updateServiceParameter);
			List<String> updatemAnnList1 = new ArrayList<String>();
			updatemAnnList1.add("PutMapping(\"/update\")");
			updateService.setMethodAnnotation(updatemAnnList1);
			
			
			
			methodInfos1.add(updateService);
			
			
			