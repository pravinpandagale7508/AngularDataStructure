package com.utcl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import com.utcl.domain.Vendor;
import com.utcl.domain.VendorA;

@NoRepositoryBean
public interface MappedTypeRepository<T extends Vendor>
  extends Repository<T,Long> {
	
	//@Query("select t from #{#entityName} t where t.name = ?1 and t.region = ?2")
	  //List<T> findByNameAndRegion(String name,String region);
	public T findByNameAndRegion(@Param("name") String name,@Param("region") String region);

	public T save(T vendor);
}
