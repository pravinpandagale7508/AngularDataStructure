package com.utcl.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.utcl.domain.RoleEnum;
import com.utcl.domain.RoleObject;
import com.utcl.domain.User;


public interface UserRepo extends JpaRepository<User, Long>{
	//Optional<RoleObject> findByRoleName(RoleEnum name);
}
