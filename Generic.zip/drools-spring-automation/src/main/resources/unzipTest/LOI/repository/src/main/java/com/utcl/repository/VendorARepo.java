package com.utcl.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.utcl.domain.RoleEnum;
import com.utcl.domain.RoleObject;
import com.utcl.domain.User;
import com.utcl.domain.Vendor;
import com.utcl.domain.VendorA;
import com.utcl.domain.VendorB;
import com.utcl.record.VendorARecord;


public interface VendorARepo extends JpaRepository<VendorA, Long>{
	public VendorARecord findByNameAndRegion(@Param("name") String name,@Param("region") String region);
}
