package com.utcl.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.utcl.domain.RoleEnum;
import com.utcl.domain.RoleObject;


public interface RoleRepo extends JpaRepository<RoleObject, Long>{
	Optional<RoleObject> findByRoleName(RoleEnum name);
}
