package com.utcl.Inf;


public interface VendorServiceB{

	//public Vendor_B getFields();
}
