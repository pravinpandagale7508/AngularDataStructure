//package com.utcl.impl;
//
//import com.utcl.Inf.VendorServiceB;
//
//import entity.Vendor_B;
//
//public class VendorBImpl {
//
//	public Vendor_B getFields() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	/*
//	 * @Override public void getUserRole(String vendorID) { // TODO Auto-generated
//	 * method stub
//	 * 
//	 * }
//	 */
//
//
//}
