package com.utcl.Inf;

public abstract class Vendor implements VendorService {
	private String name;
	private String kyc;
	private String region;
	private String address;
}
