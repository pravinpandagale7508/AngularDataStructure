package com.utcl.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.utcl.Inf.VendorService;
import com.utcl.domain.RoleEnum;
import com.utcl.domain.RoleObject;
import com.utcl.domain.Vendor;
import com.utcl.domain.VendorA;
import com.utcl.record.VendorARecord;
import com.utcl.repository.RoleRepo;
import com.utcl.repository.VendorARepo;
import com.utcl.repository.VendorBRepo;

import jakarta.annotation.PostConstruct;
import com.utcl.domain.RoleEnum;

@Service
public class VendorServiceImpl implements VendorService {

	@Autowired
	private RoleRepo roleRepositoryRepo;

	@Autowired
	private VendorARepo vendorARepo;

	@Autowired
	private VendorBRepo vendorBRepo;

	@Override
	public void getUserRole(String vendorID) {
		// TODO Auto-generated method stub

	}

	// @PostConstruct
	public void addVendor() {
		VendorA vendor = new VendorA();
		vendor.setAddress("Asdf");
		vendor.setKyc("Yes");
		vendor.setFirstName("Pravin");
		vendor.setLastName("Pandagale");
		vendor.setNickName("Pravin");
		vendor.setRegion("A");
		vendorARepo.save(vendor);
	}

	@Override
	public VendorARecord getVendorA(String vendorName, String region) {
		// Vendor va =vendorRepo.findByNameAndRegion(vendorName, region);
		// return vendorRepo.findByNameAndRegion(vendorName, region);
		return vendorARepo.findByNameAndRegion(vendorName, region);
	}

	public Object getVendor(String vendorName, RoleObject ro) {

		return switch (ro.getRoleName()) {

		case VENDOR_A -> vendorARepo.findByNameAndRegion(vendorName, ro.getRegion());

		case VENDOR_B -> vendorBRepo.findByNameAndRegion(vendorName, ro.getRegion());

		default -> new HashMap<String, Object>();

		};
	}

	@Override
	public Object getVendor(String vendorName, String region) {
		return switch (region) {

		case "A" -> vendorARepo.findByNameAndRegion(vendorName, region);

		case "B" -> vendorBRepo.findByNameAndRegion(vendorName, region);

		default -> new HashMap<String, Object>();

		};
	}
}
