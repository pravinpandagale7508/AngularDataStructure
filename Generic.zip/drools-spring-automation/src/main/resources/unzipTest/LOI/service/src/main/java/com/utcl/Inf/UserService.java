package com.utcl.Inf;

import java.util.List;

import com.utcl.domain.RoleObject;
import com.utcl.domain.User;
import com.utcl.record.UserRecord;

public interface UserService {	
	public UserRecord addUser(UserRecord record);
	public List<UserRecord> getUsers();
	public List<RoleObject> getRoles();
}
