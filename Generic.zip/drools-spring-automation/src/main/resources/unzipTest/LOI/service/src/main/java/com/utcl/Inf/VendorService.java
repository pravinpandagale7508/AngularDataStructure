package com.utcl.Inf;

import com.utcl.domain.Vendor;
import com.utcl.record.VendorARecord;

public interface VendorService {	
	 void getUserRole(String vendorID);

	VendorARecord getVendorA(String vendorName, String region);
	Object getVendor(String vendorName, String region);
}
