package com.utcl.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.utcl.Inf.UserService;
import com.utcl.Inf.VendorService;
import com.utcl.domain.MapperUtil;
import com.utcl.domain.RoleObject;
import com.utcl.domain.User;
import com.utcl.record.UserRecord;
import com.utcl.repository.RoleRepo;
import com.utcl.repository.UserRepo;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo userRepo;

	@Autowired
	private RoleRepo roleRepo;
	@Autowired
	private MapperUtil mapperUtil;

	@Override
	public UserRecord addUser(UserRecord record) {
		RoleObject ro = roleRepo.findById(record.roleId()).get();
		User u = new User();
		u.setActiveUser(true);
		u.setDescription(record.description());
		u.setRole(ro);
		u.setFullName(record.userName());
		u.setPassword(record.password());
		u.setUserName(record.userName());
		// (User) mapperUtil.getConvertedObject(record,User.class);
		// convert to record and return
		u = userRepo.save(u);
		UserRecord ur = new UserRecord(u.getId(), ro.getId(), u.getUserName(), null, u.getDescription(),
				u.getActiveUser());
		return ur;
	}

	@Override
	public List<RoleObject> getRoles() {
		// TODO Auto-generated method stub
		return roleRepo.findAll();
	}

	@Override
	public List<UserRecord> getUsers() {
		List<User> allUsers = userRepo.findAll();
		return allUsers.stream().map(u -> {
			return new UserRecord(u.getId(), u.getRole().getId(), u.getUserName(), null, u.getDescription(),
					u.getActiveUser());
		}).collect(Collectors.toList());

	}

}
