package com.utcl.impl;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.utcl.domain.RoleEnum;
import com.utcl.domain.RoleObject;
import com.utcl.repository.RoleRepo;


@Component
public class RoleSeeder implements ApplicationListener<ContextRefreshedEvent> {
    private final RoleRepo roleRepository;


    public RoleSeeder(RoleRepo roleRepository) {
        this.roleRepository = roleRepository;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        this.loadRoles();
    }

    private void loadRoles() {
        RoleEnum[] roleNames = new RoleEnum[] { RoleEnum.USER, RoleEnum.ADMIN, RoleEnum.SUPER_ADMIN ,RoleEnum.VENDOR_A,RoleEnum.VENDOR_B,RoleEnum.VENDOR_C};
        Map<RoleEnum, String> roleDescriptionMap = Map.of(
            RoleEnum.USER, "Default user role",
            RoleEnum.ADMIN, "Administrator role",
            RoleEnum.SUPER_ADMIN, "Super Administrator role",
            RoleEnum.VENDOR_A, "vendor A has some A region",
            RoleEnum.VENDOR_B, "vendor B has some B region",
            RoleEnum.VENDOR_C, "vendor C has some C region"
        );

        Arrays.stream(roleNames).forEach((roleName) -> {
            Optional<RoleObject> optionalRole = roleRepository.findByRoleName(roleName);

            optionalRole.ifPresentOrElse(System.out::println, () -> {
                RoleObject roleToCreate = new RoleObject();
                roleToCreate.setRoleName(roleName);
                roleToCreate.setDescription(roleDescriptionMap.get(roleName));      
                roleRepository.save(roleToCreate);
            });
        });
    }
}