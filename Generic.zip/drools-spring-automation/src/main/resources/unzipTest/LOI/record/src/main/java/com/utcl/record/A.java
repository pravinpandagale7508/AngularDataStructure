package com.utcl.record;

public interface A {
	public void add();
}
