package com.utcl.record;

public record UserRecord(Long id,Long roleId,String userName,String password,String description,Boolean  active) {}
