package com.utcl.record;

public record VendorBRecord(Long id, String name, String kyc, String address, String region, String asdf, String xyz,
		String pqr) {}
