package com.utcl.record;

public record VendorARecord(String firstName,String lastName,String nickName,Long id,String name,String kyc,String address,String region)  {
}
