package com.utcl.domain;

public enum RoleEnum {
	USER,
    ADMIN,
    SUPER_ADMIN,
    VENDOR_A,
    VENDOR_B,
    VENDOR_C
}
