package com.utcl.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "Vendor")
public class VendorA extends Vendor {

    private String firstName;
    private String lastName;
    private String nickName;
    // Constructors, getters, setters, other fields...
}