package com.utcl.domain;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.utcl.record.UserRecord;

@Component
public class MapperUtil {
	static ObjectMapper mapper = new ObjectMapper();
	public static Object getConvertedObject(Object fromValue, Class<?> toValueType) {
		return mapper.convertValue(fromValue, toValueType);
	}
	
	//@Autowired
	private ModelMapper modelMapper = new ModelMapper();

	public User toUser(UserRecord userDTO) {

		return modelMapper.map(userDTO, User.class);
	}

	public UserRecord toUserDTO(User user) {
		return modelMapper.map(user, UserRecord.class);
	}

	
}
