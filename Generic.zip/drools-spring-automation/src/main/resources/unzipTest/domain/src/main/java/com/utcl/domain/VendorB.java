package com.utcl.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "Vendor")
public class VendorB extends Vendor {

    private String asdf;
    private String xyz;
    private String pqr;
    // Constructors, getters, setters, other fields...
}