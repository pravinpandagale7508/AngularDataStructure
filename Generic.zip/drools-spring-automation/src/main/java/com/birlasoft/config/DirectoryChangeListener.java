package com.birlasoft.config;

import org.apache.commons.io.monitor.FileAlterationListener;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.springframework.context.ApplicationContext;

import com.birlasoft.Application;

import java.io.File;

public class DirectoryChangeListener implements FileAlterationListener {

    private final ApplicationContext applicationContext;

    public DirectoryChangeListener(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Override
    public void onStart(FileAlterationObserver observer) {
    	System.out.println("onStart");
        // Called when monitoring of the directory starts
    }

    @Override
    public void onDirectoryCreate(File directory) {
    	System.out.println(directory.getName());
        // Called when a new directory is created in the monitored directory
    }

    @Override
    public void onDirectoryChange(File directory) {
        // Called when a directory in the monitored directory is changed
        triggerRefresh();
    }

    @Override
    public void onDirectoryDelete(File directory) {
        // Called when a directory is deleted from the monitored directory
    }

    @Override
    public void onFileCreate(File file) {
        // Called when a new file is created in the monitored directory
    }

    @Override
    public void onFileChange(File file) {
        // Called when a file in the monitored directory is changed
        triggerRefresh();
    }

    @Override
    public void onFileDelete(File file) {
        // Called when a file is deleted from the monitored directory
    }

    @Override
    public void onStop(FileAlterationObserver observer) {
        // Called when monitoring of the directory stops
    }

    private void triggerRefresh() {
    	Application.scanAndRegisterBeans("com.birlasoft.drools.*");
        // Logic to trigger a refresh mechanism in the application context
        // For example, you can use ApplicationContext#refresh() or any other mechanism to reload resources
//    	Thread restartThread = new Thread(() -> {
//            try {
//                Thread.sleep(1000);
//               // Application.scanAndRegisterBeans("com.birlasoft.drools.*");
//            } catch (InterruptedException ignored) {
//            }
//        });
//        restartThread.setDaemon(false);
//        restartThread.start();
    }
}
