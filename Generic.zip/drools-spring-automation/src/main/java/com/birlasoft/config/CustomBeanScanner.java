package com.birlasoft.config;

import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.annotation.ClassPathBeanDefinitionScanner;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.type.filter.AnnotationTypeFilter;

public class CustomBeanScanner extends ClassPathBeanDefinitionScanner {

    public CustomBeanScanner(BeanDefinitionRegistry registry) {
        super(registry);
    }

   

}
