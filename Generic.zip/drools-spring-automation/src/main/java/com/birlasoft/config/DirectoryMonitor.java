package com.birlasoft.config;

import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.birlasoft.project.services.specification.ProjectSpecificCreators;

import jakarta.annotation.PostConstruct;

import java.io.File;
import java.util.concurrent.TimeUnit;

@Component
public class DirectoryMonitor {

    private final ApplicationContext applicationContext;

    public DirectoryMonitor(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @PostConstruct
    public void startMonitoring() {
        // Directory to monitor
    	
    	String rootPath = System.getProperty(ProjectSpecificCreators.USER_DIR);
		String outputPath = rootPath + File.separator + ProjectSpecificCreators.SRC_DIR + File.separator
				+ ProjectSpecificCreators.MAIN_DIR + File.separator + ProjectSpecificCreators.JAVA_DIR
				+ File.separator
				+ ProjectSpecificCreators.COM_DIR + File.separator + "birlasoft"+File.separator +"drools";
        String directoryPath = "/path/to/directory";

        // Create a new observer for the directory
        FileAlterationObserver observer = new FileAlterationObserver(outputPath);

        // Register a listener for file changes
        observer.addListener(new DirectoryChangeListener(applicationContext));

        // Create a monitor and add the observer
        FileAlterationMonitor monitor = new FileAlterationMonitor(1000);
        monitor.addObserver(observer);

        try {
            // Start the monitor
          // monitor.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
