package com.birlasoft.project.services.specification;

public interface ProjectSpecificCreators {
	
	static String DROOL_DTO_IMPORT_DIR = "import com.birlasoft.drools.";
	static String DROOR_DIALECT="dialect \"mvel\"";
	static String DROOR_RULE="rule \"%s\"";
	static String DROOL_WHEN="when \n\t %s : %s; ";
	static String DROOL_THEN="then \n\t %s";
	static String DROOL_END="end;";
	// Directory details
	static String USER_DIR = "user.dir";
	static String OUTPUT_DIR = "output";
	static String SRC_DIR = "src";
	static String MAIN_DIR = "main";
	static String JAVA_DIR = "java";
	static String RESOURCES_DIR = "resources";
	static String COM_DIR = "com";
	static String BIRLA_DIR = "birlasoft/drools";
	static String TEST_DIR = "test";
	static String ENTITY_DIR = "entities";
	static String REPO_DIR = "Repo";

	// Annotation Info
	static String KEY_NOARGSCONSTRUCTOR = "NoArgsConstructor";
	static String VAL_NOARGSCONSTRUCTOR = "lombok.NoArgsConstructor";

	static String KEY_DATA = "Data";
	static String VAL_DATA = "lombok.Data";

	static String KEY_ENTITY = "Entity";
	static String VAL_ENTITY = "jakarta.persistence.Entity";

	static String TABLE_NAME_ANNO = "Table(name = " + "\"" + "%s" + "\"" + ")";
	static String GENERATED_VAL = "GeneratedValue(strategy = GenerationType.IDENTITY)";
	static String COLUMN_ANN = "Column(unique = true)";
	static String PUT_MAPP_ANN = "PutMapping(\"/%s\")";
	static String DEL_MAPP_ANN = "DeleteMapping(\"/%s\")";
	static String GET_MAPP_ANN = "GetMapping(\"/%s\")";
	static String POST_MAPP_ANN = "PostMapping(\"/%s\")";
	// Suppress warnings
	static String UNCHECKED = "unchecked";
	static String RAWTYPES = "rawtypes";

	// POM details
	static String POM_FILE = "pom.xml";
	static String POM_DIR = "/pom.xml";
	static String GROUP_ID_STR = "<groupId>com.birlasoft</groupId>";
	static String GROUP_ID_OPENTAG = "<groupId>";
	static String GROUP_ID_CLOSETAG = "</groupId>";
	static String ARTIFACT_ID_STR = "<artifactId>spring-automation</artifactId>";
	static String ARTIFACT_ID_OPENTAG = "<artifactId>";
	static String ARTIFACT_ID_CLOSETAG = "</artifactId>";
	static String NAME_STR = "<name>spring-automation</name>";
	static String NAME_OPENTAG = "<name>";
	static String NAME_CLOSETAG = "</name>";
	static String DESC_STR = "<description>Project for Spring Automation</description>";
	static String DESC_OPENTAG = "<description>";
	static String DESC_CLOSETAG = "</description>";

	// General Creators
	static String APP_MAIN_INNERCONTENT = "SpringApplication.run(Application.class, args)";

}
