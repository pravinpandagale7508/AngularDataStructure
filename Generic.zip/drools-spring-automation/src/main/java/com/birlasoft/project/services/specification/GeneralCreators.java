package com.birlasoft.project.services.specification;

public interface GeneralCreators {
	static String REPO = "repository";
	static String SERVICE = "Service";
	static String SMALL_SERVICE = "service";
	static String ADD = "Add";
	static String SMALL_ADD = "add";
	static String METHOD_RETURN_OBJECT = "Object";
	static String METHOD_VOID = "void";
	static String DTO = "Dto";
	static String SMALL_DTO = "dto";
	static String GET_ALL = "getAll";
	static String APPLY="apply";
	static String UPDATE = "update";
	static String DELETE = "delete";
	static String GET_BY_ID = "getByID";
	static String ENTITIES = "entities";
	static String PACKAGE_SPACE = "package ";
	static String SEMICOLON = ";";
	static String DOT = ".";
	static String OPENING_ROUND = "(";
	static String CLOSING_ROUND = ")";
	static String EMPTY_STRING = "";
	static String AUTOWIRED = "Autowired";
	static String SERVICE_IMPL = "ServiceImpl";
	static String CAMEL_SERVICE_IMPL = "serviceImpl";
	static String CONTROLLER = "Controller";
	static String REST_CONTROLLER = "RestController";
	static String APPLICATION = "Application";
	static String SMALL_APPLICATION = "application";
	static String SPRING_BOOT_APP = "SpringBootApplication";
	static String MAIN = "main";
	static String STRING_ARRAY = "String[]";
	static String ARGS = "args";	
	static String VOID = "void";
	static String SMALL_IMPL = "impl";
	static String RETURN_SPACE = "return ";
	static String OBJECT = "Object";
	static String DATA = "Data";
	static String NEW_LINE = "\n";
	static String JPA_REPO = "JpaRepository<" + "%s" + ", " + "%s"  + ">";
	
	static String LONG = "Long";
	
}
