package com.birlasoft.project.dto;

import java.util.ArrayList;
import java.util.List;

public class ClassInfo {
	private String className;
	private List<Field> fields = new ArrayList<Field>();// field
	private List<AnnotationInfo> annotationList = new ArrayList<AnnotationInfo>();
	private List<ExtendInfo> extendInfoList = new ArrayList<ExtendInfo>();
	private List<String> otherImportsList = new ArrayList<String>();
	private List<MethodInfo> methodInfos = new ArrayList<MethodInfo>();
	
	
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public List<Field> getFields() {
		return fields;
	}
	public void setFields(List<Field> fields) {
		this.fields = fields;
	}
	public List<AnnotationInfo> getAnnotationList() {
		return annotationList;
	}
	public void setAnnotationList(List<AnnotationInfo> annotationList) {
		this.annotationList = annotationList;
	}
	public List<ExtendInfo> getExtendInfoList() {
		return extendInfoList;
	}
	public void setExtendInfoList(List<ExtendInfo> extendInfoList) {
		this.extendInfoList = extendInfoList;
	}
	public List<String> getOtherImportsList() {
		return otherImportsList;
	}
	public void setOtherImportsList(List<String> otherImportsList) {
		this.otherImportsList = otherImportsList;
	}
	public List<MethodInfo> getMethodInfos() {
		return methodInfos;
	}
	public void setMethodInfos(List<MethodInfo> methodInfos) {
		this.methodInfos = methodInfos;
	}
	
	
}
