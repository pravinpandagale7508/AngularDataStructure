package com.birlasoft.project.services.specificationImpl;

import java.util.List;

import org.springframework.stereotype.Component;

import com.birlasoft.project.dto.ClassInfo;
import com.birlasoft.project.dto.ExtendInfo;
import com.birlasoft.project.services.specification.GeneralCreators;
import com.birlasoft.project.services.specification.OrgImports;
import com.birlasoft.project.services.specification.ProjectSpecificCreators;
import com.birlasoft.project.utility.FileUtil;
import com.github.javaparser.ast.CompilationUnit;

@Component
public class ProcessingService {
	public void repoProcessing(String className) {
//		ClassInfo repoInfo = new ClassInfo();
//		
//		repoInfo.setClassName(className + ProjectSpecificCreators.REPO_DIR);
//		List<ExtendInfo> extendInfos = repoInfo.getExtendInfoList(); 
//				extendInfos.add(new ExtendInfo(String.format(GeneralCreators.JPA_REPO, className,idFieldRec.type()),
//						OrgImports.ORG_JPA_REPO));
//				/*extendInfos.add(new ExtendInfo("JpaRepository<" + entityInfo.getClassName() + ", " + idFieldRec.type() + ">",
//						OrgImports.ORG_JPA_REPO));*/
//		repoInfo.setExtendInfoList(extendInfos);
//		List<String> otherImports = repoInfo.getOtherImportsList();
//		otherImports.add(
//				FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath()) + "." + entityInfo.getClassName());
//		repoInfo.setOtherImportsList(otherImports);
//		CompilationUnit cRepo = repoCreator.createRepo(initialJavaDir, repoInfo, GeneralCreators.REPO);

	}
}
