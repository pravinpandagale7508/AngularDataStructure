package com.birlasoft.project.dto;

import java.util.List;
import java.util.Map;

public record RequestRecord(ProjectMetaInfo projectMetaInfo,List<EntityDetails> listOfEntities,List<Map<String,Object>>rules) {

}
