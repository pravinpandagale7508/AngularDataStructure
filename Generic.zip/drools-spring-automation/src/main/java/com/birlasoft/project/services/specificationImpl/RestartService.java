package com.birlasoft.project.services.specificationImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.restart.RestartEndpoint;
import org.springframework.stereotype.Service;

import com.birlasoft.Application;

@Service
public class RestartService {
    
    @Autowired
    private RestartEndpoint restartEndpoint;
    
    public void restartApp() {
        
        Thread restartThread = new Thread(() -> {
            try {
                Thread.sleep(1000);
                restartEndpoint.restart();
            } catch (InterruptedException ignored) {
            }
        });
        restartThread.setDaemon(false);
        restartThread.start();
    }
}