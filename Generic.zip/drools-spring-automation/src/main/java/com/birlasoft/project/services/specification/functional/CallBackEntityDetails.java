package com.birlasoft.project.services.specification.functional;

import com.birlasoft.project.dto.EntityDetails;

@FunctionalInterface
public interface CallBackEntityDetails {
	public void setEntityDetails(EntityDetails details);
}