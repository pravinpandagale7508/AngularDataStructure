package com.birlasoft.project;

import com.birlasoft.project.dto.CreationStep;

public class StageInfo {
	// Static variable reference of single_instance
	// of type StageInfo
	private static StageInfo stage_instance = null;

	// Declaring a variable of type String

	public CreationStep pomCreationStep;	
	public CreationStep entityCreationStep;
	public CreationStep entityDtoCreationStep;
	public CreationStep repoCreationStep;
	public CreationStep serviceSpecificationCreationStep;
	public CreationStep serviceImplCreationStep;
	public CreationStep controllerCreationStep;
	public CreationStep applicatonCreationStep;
	public CreationStep defaultCreationStep ;

	// Constructor
		// Here we will be creating private constructor
		// restricted to this class itself
		private StageInfo() {
			this.pomCreationStep = new CreationStep("Pom", "", 1);
			//this.pomCreationStep = new CreationStep("Pom", "", 1);
		}
	
	

	

	public CreationStep getPomCreationStep() {
			return pomCreationStep;
		}





		public void setPomCreationStep(CreationStep pomCreationStep) {
			this.pomCreationStep = pomCreationStep;
		}





		public CreationStep getEntityDtoCreationStep() {
			return entityDtoCreationStep;
		}





		public void setEntityDtoCreationStep(CreationStep entityDtoCreationStep) {
			this.entityDtoCreationStep = entityDtoCreationStep;
		}





		public CreationStep getEntityCreationStep() {
			return entityCreationStep;
		}





		public void setEntityCreationStep(CreationStep entityCreationStep) {
			this.entityCreationStep = entityCreationStep;
		}





		public CreationStep getRepoCreationStep() {
			return repoCreationStep;
		}





		public void setRepoCreationStep(CreationStep repoCreationStep) {
			this.repoCreationStep = repoCreationStep;
		}





		public CreationStep getServiceSpecificationCreationStep() {
			return serviceSpecificationCreationStep;
		}





		public void setServiceSpecificationCreationStep(CreationStep serviceSpecificationCreationStep) {
			this.serviceSpecificationCreationStep = serviceSpecificationCreationStep;
		}





		public CreationStep getServiceImplCreationStep() {
			return serviceImplCreationStep;
		}





		public void setServiceImplCreationStep(CreationStep serviceImplCreationStep) {
			this.serviceImplCreationStep = serviceImplCreationStep;
		}





		public CreationStep getControllerCreationStep() {
			return controllerCreationStep;
		}





		public void setControllerCreationStep(CreationStep controllerCreationStep) {
			this.controllerCreationStep = controllerCreationStep;
		}





		public CreationStep getApplicatonCreationStep() {
			return applicatonCreationStep;
		}





		public void setApplicatonCreationStep(CreationStep applicatonCreationStep) {
			this.applicatonCreationStep = applicatonCreationStep;
		}





		public CreationStep getDefaultCreationStep() {
			return defaultCreationStep;
		}





		public void setDefaultCreationStep(CreationStep defaultCreationStep) {
			this.defaultCreationStep = defaultCreationStep;
		}





	// Static method
	// Static method to create instance of StageInfo class
	public static synchronized StageInfo getInstance() {
		if (stage_instance == null)
			stage_instance = new StageInfo();

		return stage_instance;
	}
}