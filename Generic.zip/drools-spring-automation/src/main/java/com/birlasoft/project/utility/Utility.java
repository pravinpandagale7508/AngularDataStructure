package com.birlasoft.project.utility;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import com.birlasoft.project.services.specification.ProjectSpecificCreators;

public class Utility {
	public static byte[] readAllBytes(InputStream inputStream) throws IOException {
		final int bufLen = 1024;
		byte[] buf = new byte[bufLen];
		int readLen;
		IOException exception = null;

		try {
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

			while ((readLen = inputStream.read(buf, 0, bufLen)) != -1)
				outputStream.write(buf, 0, readLen);

			return outputStream.toByteArray();
		} catch (IOException e) {
			exception = e;
			throw e;
		} finally {
			if (exception == null)
				inputStream.close();
			else
				try {
					inputStream.close();
				} catch (IOException e) {
					exception.addSuppressed(e);
				}
		}
	}
	public static void buildProject() {
		try {
			System.out.println("Building Project wait for few moment...");
            // Change directory to where your pom.xml is located
			String rootPath = System.getProperty(ProjectSpecificCreators.USER_DIR);
            String myArgs = rootPath+"/mvnw.cmd spring-boot:run";
            Process p = Runtime.getRuntime().exec(myArgs, null);
            int exitCode = p.waitFor();
            if (exitCode == 0) {
                System.out.println("Build successful");
            } else {
                System.err.println("Build failed");
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
	
}
