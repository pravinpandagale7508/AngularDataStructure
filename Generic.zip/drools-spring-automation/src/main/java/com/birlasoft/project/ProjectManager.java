package com.birlasoft.project;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.birlasoft.Application;
import com.birlasoft.project.dto.AnnotationInfo;
import com.birlasoft.project.dto.ClassInfo;
import com.birlasoft.project.dto.CreationStep;
import com.birlasoft.project.dto.EntityDetails;
import com.birlasoft.project.dto.ExtendInfo;
import com.birlasoft.project.dto.Field;
import com.birlasoft.project.dto.FieldRecord;
import com.birlasoft.project.dto.MethodInfo;
import com.birlasoft.project.dto.MethodInfo.Parameter;
import com.birlasoft.project.dto.Pom;
import com.birlasoft.project.dto.ProjectDetail;
import com.birlasoft.project.dto.ProjectMetaInfo;
import com.birlasoft.project.dto.RequestRecord;
import com.birlasoft.project.services.specification.GeneralCreators;
import com.birlasoft.project.services.specification.JakartaImports;
import com.birlasoft.project.services.specification.OrgImports;
import com.birlasoft.project.services.specification.ProjectSpecificCreators;
import com.birlasoft.project.services.specificationImpl.ApplicationCreator;
import com.birlasoft.project.services.specificationImpl.ControllerCreator;
import com.birlasoft.project.services.specificationImpl.DroolFileProcessor;
import com.birlasoft.project.services.specificationImpl.EntityCreator;
import com.birlasoft.project.services.specificationImpl.PomGenerator;
import com.birlasoft.project.services.specificationImpl.RepositoryCreator;
import com.birlasoft.project.services.specificationImpl.ResourcesGenerator;
import com.birlasoft.project.services.specificationImpl.RestartService;
import com.birlasoft.project.services.specificationImpl.ServicesCreator;
import com.birlasoft.project.services.specificationImpl.ServicesCreatorImpl;
import com.birlasoft.project.utility.FileUtil;
import com.birlasoft.project.utility.Utility;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Modifier.Keyword;

import jakarta.annotation.PostConstruct;

@Service
public class ProjectManager {
	@Autowired
	EntityCreator entityCreator;

	@Autowired
	RestartService restartService;
	@Autowired
	RepositoryCreator repoCreator;

	@Autowired
	ServicesCreator servicesCreator;

	@Autowired
	ServicesCreatorImpl servicesCreatorImpl;

	@Autowired
	ControllerCreator controllerCreator;

	@Autowired
	ApplicationCreator applicationCreator;

	@Autowired
	PomGenerator pomGenerator;
	@Autowired
	ResourcesGenerator resourcesGenerator;

	List<ProjectDetail> projectDetailsList;

	@Value("${numberOfProj}")
	private String numberOfProj;

	@PostConstruct
	public void postCons() {
		// processProject("Test");
	}

	public void processDrool(RequestRecord request) {
		try {
			
			String rootPath = System.getProperty(ProjectSpecificCreators.USER_DIR);
			String outputPath = rootPath + File.separator + ProjectSpecificCreators.SRC_DIR + File.separator
					+ ProjectSpecificCreators.MAIN_DIR + File.separator + ProjectSpecificCreators.JAVA_DIR
					+ File.separator;
			File mainDir = FileUtil.createDirectory(outputPath);
			System.out.println(mainDir.getCanonicalPath());
			File initialJavaDir = FileUtil.createDirectory(outputPath);
			// Resources directory

			List<EntityDetails> listOfEntities = request.listOfEntities();

			for (EntityDetails entityDetails : listOfEntities) {

				try {
					// Entity creation And Entity Dto
					ClassInfo entityInfo = new ClassInfo();
					entityInfo.setClassName(entityDetails.name());
					List<AnnotationInfo> entityAnnList = new ArrayList<AnnotationInfo>();
					entityAnnList.add(new AnnotationInfo(
							String.format(ProjectSpecificCreators.TABLE_NAME_ANNO, entityInfo.getClassName()),
							JakartaImports.JAKARTA_TABLE));
					entityAnnList.add(new AnnotationInfo(ProjectSpecificCreators.KEY_NOARGSCONSTRUCTOR,
							ProjectSpecificCreators.VAL_NOARGSCONSTRUCTOR));
					entityAnnList.add(
							new AnnotationInfo(ProjectSpecificCreators.KEY_DATA, ProjectSpecificCreators.VAL_DATA));
					entityAnnList.add(
							new AnnotationInfo(ProjectSpecificCreators.KEY_ENTITY, ProjectSpecificCreators.VAL_ENTITY));
					// @Entity

					entityInfo.setAnnotationList(entityAnnList);
					List<String> entOtherImps = entityInfo.getOtherImportsList();
					List<FieldRecord> inputFields = entityDetails.listOfFields();
					FieldRecord idFieldRec = inputFields.stream().filter(fr -> fr.isId()).findFirst().get();

					List<Field> fields = inputFields.stream().map(fr -> {
						Field field1 = null;
						List<String> field1AnnList = new ArrayList<String>();
						if (fr.isId()) {
							field1AnnList.add(JakartaImports.ID);
							entOtherImps.add(JakartaImports.JAKARTA_ID);
							field1AnnList.add(ProjectSpecificCreators.GENERATED_VAL);
							entOtherImps.add(JakartaImports.JAKARTA_GENERATED_VAL);
							entOtherImps.add(JakartaImports.JAKARTA_GENERATED_TYPE);
							// jakarta.persistence.Column
						} else if (fr.isUnique()) {
							entOtherImps.add(JakartaImports.JAKARTA_COLUMN);
							field1AnnList.add(ProjectSpecificCreators.COLUMN_ANN);
						} else {
							entOtherImps.add(JakartaImports.JAKARTA_COLUMN);
							// field1AnnList.add("Column(unique = false)");
						}

						field1 = new Field(fr.name(), fr.type(),
								FileUtil.getPackageNameByClassName(fr.type()) + "." + fr.type(), field1AnnList);

						return field1;
					}).collect(Collectors.toList());
					entityInfo.setFields(fields);
					entityInfo.setOtherImportsList(entOtherImps);
					String entPath = initialJavaDir.getCanonicalPath() + File.separator
							+ ProjectSpecificCreators.COM_DIR + File.separator + ProjectSpecificCreators.BIRLA_DIR
							+ File.separator + ProjectSpecificCreators.ENTITY_DIR;

					File entitiesDir = FileUtil.createDirectory(entPath);

					entityCreator.createEntity(initialJavaDir, entityInfo, entitiesDir);
					// Repository creation
					ClassInfo repoInfo = new ClassInfo();

					repoInfo.setClassName(entityInfo.getClassName() + ProjectSpecificCreators.REPO_DIR);
					List<ExtendInfo> extendInfos = repoInfo.getExtendInfoList();
					extendInfos.add(new ExtendInfo(
							String.format(GeneralCreators.JPA_REPO, entityInfo.getClassName(), idFieldRec.type()),
							OrgImports.ORG_JPA_REPO));
					repoInfo.setExtendInfoList(extendInfos);
					List<String> otherImports = repoInfo.getOtherImportsList();
					otherImports.add(FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath()) + "."
							+ entityInfo.getClassName());
					repoInfo.setOtherImportsList(otherImports);
					String repoSubDir = GeneralCreators.REPO;

					CompilationUnit cRepo = repoCreator.createRepo(initialJavaDir, repoInfo, repoSubDir);

					// Services creation
					ClassInfo serviceInfo = new ClassInfo();
					serviceInfo.setClassName(entityInfo.getClassName() + GeneralCreators.SERVICE);
					List<String> otherSerImports = repoInfo.getOtherImportsList();
					otherSerImports.add(FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath()) + "."
							+ entityInfo.getClassName());
					repoInfo.setOtherImportsList(otherSerImports);

					List<MethodInfo> methodInfos = serviceInfo.getMethodInfos();
					Keyword k = Modifier.Keyword.PUBLIC;
					Keyword[] keywords = new Keyword[1];
					keywords[0] = k;

					List<Parameter> parameters = new ArrayList<MethodInfo.Parameter>();

					MethodInfo m1 = new MethodInfo(GeneralCreators.SMALL_ADD + entityDetails.name(), keywords,
							new ArrayList<String>());
					
					
					List<String> m1AnnListSer = new ArrayList<String>();
					m1AnnListSer.add(String.format(ProjectSpecificCreators.POST_MAPP_ANN, entityInfo.getClassName().toLowerCase()+"/add"));
					m1AnnListSer.add("Hidden");
					m1.setMethodAnnotation(m1AnnListSer);
					
					parameters.add(new Parameter(entityDetails.name() + GeneralCreators.DTO,
							entityDetails.name().toLowerCase(), null, null));
					m1.setParameters(parameters);
					m1.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);

					MethodInfo m2 = new MethodInfo(GeneralCreators.GET_ALL + entityDetails.name(), keywords,
							new ArrayList<String>());
					m2.setParameters(new ArrayList<MethodInfo.Parameter>());
					m2.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);

					MethodInfo updateService = new MethodInfo(GeneralCreators.UPDATE + entityDetails.name(), keywords,
							new ArrayList<String>());
					updateService.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);
					List<MethodInfo.Parameter> updateServiceParameter = new ArrayList<MethodInfo.Parameter>();

					List<String> updateParaAnnListSer = new ArrayList<String>();
					// updateParaAnnListSer.add("RequestBody");
					List<String> updateParaImportListSer = new ArrayList<String>();
					// updateParaImportListSer.add("org.springframework.web.bind.annotation.RequestBody");

					updateServiceParameter.add(new Parameter(entityDetails.name() + "Dto",
							entityDetails.name().toLowerCase(), updateParaImportListSer, updateParaAnnListSer));
					updateService.setParameters(updateServiceParameter);
					List<String> updatemAnnListSer = new ArrayList<String>();
					updatemAnnListSer.add(String.format(ProjectSpecificCreators.PUT_MAPP_ANN, entityInfo.getClassName().toLowerCase()+"/update"));
					updatemAnnListSer.add("Hidden");
					updateService.setMethodAnnotation(updatemAnnListSer);

					// deleteMapping
					MethodInfo deleteService = new MethodInfo(GeneralCreators.DELETE + entityDetails.name(), keywords,
							new ArrayList<String>());
					deleteService.setMethodReturnType(GeneralCreators.METHOD_VOID);
					List<MethodInfo.Parameter> deleteServiceParameter = new ArrayList<MethodInfo.Parameter>();
					List<String> deleteParaAnnListSer = new ArrayList<String>();
					List<String> deleteParaImportListSer = new ArrayList<String>();

					deleteServiceParameter
							.add(new Parameter(idFieldRec.type(), "id", deleteParaImportListSer, deleteParaAnnListSer));
					deleteService.setParameters(deleteServiceParameter);
					List<String> deleteAnnList1Ser = new ArrayList<String>();
					deleteAnnList1Ser.add(String.format(ProjectSpecificCreators.DEL_MAPP_ANN, entityInfo.getClassName().toLowerCase()+"/delete"));
					deleteAnnList1Ser.add("Hidden");
					deleteService.setMethodAnnotation(deleteAnnList1Ser);

					MethodInfo applyRule = new MethodInfo(GeneralCreators.APPLY + entityDetails.name(), keywords,
							new ArrayList<String>());
//					parameters = new ArrayList<>();
//					parameters.add(new Parameter(entityDetails.name() + GeneralCreators.DTO,
//							entityDetails.name().toLowerCase(), null, null));
					applyRule.setParameters(parameters);
					applyRule.setMethodReturnType(entityDetails.name() + GeneralCreators.DTO);

					methodInfos.add(applyRule);
					methodInfos.add(updateService);
					methodInfos.add(m2);
					methodInfos.add(m1);
					methodInfos.add(deleteService);

					List<String> otherServiceImports = serviceInfo.getOtherImportsList();
					otherServiceImports.add(FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath())
							.replace(GeneralCreators.ENTITIES, GeneralCreators.SMALL_DTO) + "."
							+ entityInfo.getClassName() + GeneralCreators.DTO);
					DroolFileProcessor.processDroolFile("import "+ FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath())
							.replace(GeneralCreators.ENTITIES, GeneralCreators.SMALL_DTO) + "."
							+ entityInfo.getClassName() + GeneralCreators.DTO,true);
					// otherServiceImports.add("org.springframework.beans.factory.annotation.Autowired");
					serviceInfo.setOtherImportsList(otherServiceImports);
					String serviceSubDir = GeneralCreators.SMALL_SERVICE;

					CompilationUnit cService = servicesCreator.createService(initialJavaDir, serviceInfo,
							GeneralCreators.SMALL_SERVICE);
					// Service Impl generation

					List<AnnotationInfo> serviceImplAnnList = new ArrayList<AnnotationInfo>();

					serviceImplAnnList.add(new AnnotationInfo(GeneralCreators.SERVICE, OrgImports.ORG_SPRING_SERVICE));
					serviceInfo.setAnnotationList(serviceImplAnnList);

					List<ExtendInfo> extendInfosService = serviceInfo.getExtendInfoList();
					extendInfosService.add(new ExtendInfo(serviceInfo.getClassName(),
							cService.getPackageDeclaration().get().toString().replace(GeneralCreators.PACKAGE_SPACE, "")
									.replace(GeneralCreators.SEMICOLON,
											GeneralCreators.DOT + serviceInfo.getClassName())));
					serviceInfo.setExtendInfoList(extendInfosService);

					List<Field> serviceFields = new ArrayList<Field>();

					List<String> serviceAnnList = new ArrayList<String>();

					serviceAnnList.add(GeneralCreators.AUTOWIRED);

					Field serviceField = new Field(repoInfo.getClassName().toLowerCase(), repoInfo.getClassName(),
							cRepo.getPackageDeclaration().get().toString().replace(GeneralCreators.PACKAGE_SPACE, "")
									.replace(GeneralCreators.SEMICOLON, GeneralCreators.DOT + repoInfo.getClassName()),
							serviceAnnList);

					Field kaiCotainer = new Field("kieContainer", "KieContainer", "org.kie.api.runtime.KieContainer",
							serviceAnnList);

					serviceFields.add(serviceField);
					serviceFields.add(kaiCotainer);
					serviceInfo.setFields(serviceFields);

					otherServiceImports.add(FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath())
							+ GeneralCreators.DOT + entityInfo.getClassName());
					otherServiceImports.add(OrgImports.ORG_SPRING_AUTOWIRED);
					otherServiceImports.add("org.kie.api.runtime.KieSession");
					serviceInfo.setOtherImportsList(otherServiceImports);
					serviceInfo.setClassName(entityInfo.getClassName() + GeneralCreators.SERVICE_IMPL);

					CompilationUnit serImplCu = servicesCreatorImpl.createServiceImpl(initialJavaDir, serviceInfo,
							GeneralCreators.CAMEL_SERVICE_IMPL);

					// Controller creation

					ClassInfo controllerInfo = new ClassInfo();
					controllerInfo.setClassName(entityInfo.getClassName() + GeneralCreators.CONTROLLER);

					List<AnnotationInfo> controllerAnnList = new ArrayList<AnnotationInfo>();

					controllerAnnList.add(
							new AnnotationInfo(GeneralCreators.REST_CONTROLLER+"(\"/"+controllerInfo.getClassName().toLowerCase()+"\")", OrgImports.ORG_SPRING_RESTCONTROLLER));
					controllerInfo.setAnnotationList(controllerAnnList);

					List<String> otherContrImports = controllerInfo.getOtherImportsList();
					otherContrImports.add(OrgImports.ORG_SPRING_AUTOWIRED);
					otherContrImports.add(OrgImports.ORG_SPRING_POSTMAPPING);
					otherContrImports.add(OrgImports.ORG_SPRING_PUTMAPPING);
					otherContrImports.add(OrgImports.ORG_SPRING_DELETEMAPPING);
					otherContrImports.add(OrgImports.ORG_SPRING_GETMAPPING);

					List<MethodInfo> methodInfos1 = controllerInfo.getMethodInfos();
					Keyword k1 = Modifier.Keyword.PUBLIC;
					Keyword[] keywords1 = new Keyword[1];
					keywords1[0] = k1;
					List<Parameter> parameters1 = new ArrayList<MethodInfo.Parameter>();

					MethodInfo addCtr = new MethodInfo(GeneralCreators.SMALL_ADD + entityDetails.name(), keywords1,
							new ArrayList<String>());
					addCtr.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);
					parameters1.add(new Parameter(entityDetails.name() + GeneralCreators.DTO,
							entityDetails.name().toLowerCase(), null, null));
					addCtr.setParameters(parameters1);
					List<String> mAnnList = new ArrayList<String>();
					mAnnList.add(String.format(ProjectSpecificCreators.POST_MAPP_ANN, entityInfo.getClassName().toLowerCase()+""+GeneralCreators.SMALL_ADD));
					
					mAnnList.add("Hidden");
					
					addCtr.setMethodAnnotation(mAnnList);

					List<Parameter> ruleParameter = new ArrayList<MethodInfo.Parameter>();

					MethodInfo applyCtr = new MethodInfo(GeneralCreators.APPLY + entityDetails.name(), keywords1,
							new ArrayList<String>());
					applyCtr.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);
					ruleParameter.add(new Parameter(entityDetails.name() + GeneralCreators.DTO,
							entityDetails.name().toLowerCase(), null, null));
					applyCtr.setParameters(ruleParameter);
					List<String> applyAnnList = new ArrayList<String>();
					applyAnnList.add(String.format(ProjectSpecificCreators.POST_MAPP_ANN,entityDetails.name().toLowerCase()+"/"+ GeneralCreators.APPLY));
					applyCtr.setMethodAnnotation(applyAnnList);

					MethodInfo getCtr = new MethodInfo(GeneralCreators.GET_ALL + entityDetails.name(), keywords,
							new ArrayList<String>());
					getCtr.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);
					// parameters.add(new Parameter(entityDetails.name() + "Dto",
					// entityDetails.name().toLowerCase(), null, null));
					getCtr.setParameters(new ArrayList<MethodInfo.Parameter>());
					List<String> mAnnList1 = new ArrayList<String>();
					mAnnList1.add(String.format(ProjectSpecificCreators.GET_MAPP_ANN,entityInfo.getClassName().toLowerCase()+"/"+ GeneralCreators.GET_ALL));
					mAnnList1.add("Hidden");
					getCtr.setMethodAnnotation(mAnnList1);

					MethodInfo updateCtr = new MethodInfo(GeneralCreators.UPDATE + entityDetails.name(), keywords,
							new ArrayList<String>());
					updateCtr.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);
					List<MethodInfo.Parameter> updateCtrParameter = new ArrayList<MethodInfo.Parameter>();

					List<String> updateParaAnnList = new ArrayList<String>();
					// updateParaAnnList.add("RequestBody");
					List<String> updateParaImportList = new ArrayList<String>();
					updateParaImportList.add(OrgImports.ORG_SPRING_REQ_BODY);

					updateCtrParameter.add(new Parameter(entityDetails.name() + GeneralCreators.DTO,
							entityDetails.name().toLowerCase(), updateParaImportList, updateParaAnnList));
					updateCtr.setParameters(updateCtrParameter);
					List<String> updatemAnnList1 = new ArrayList<String>();
					updatemAnnList1.add("PutMapping(\""+entityInfo.getClassName().toLowerCase()+""+"/update\")");
					updatemAnnList1.add("Hidden");
					updateCtr.setMethodAnnotation(updatemAnnList1);

					// deleteMapping
					MethodInfo deleteCtr = new MethodInfo("delete" + entityDetails.name(), keywords,
							new ArrayList<String>());
					deleteCtr.setMethodReturnType(GeneralCreators.METHOD_VOID);
					List<MethodInfo.Parameter> deleteCtrParameter = new ArrayList<MethodInfo.Parameter>();
					List<String> deleteParaAnnList = new ArrayList<String>();
					List<String> deleteParaImportList = new ArrayList<String>();

					deleteCtrParameter
							.add(new Parameter(idFieldRec.type(), "id", deleteParaImportList, deleteParaAnnList));
					deleteCtr.setParameters(deleteCtrParameter);
					List<String> deleteAnnList1 = new ArrayList<String>();
					deleteAnnList1.add(String.format(ProjectSpecificCreators.DEL_MAPP_ANN,entityInfo.getClassName().toLowerCase()+"/"+ "delete"));
					deleteAnnList1.add("Hidden");
					deleteCtr.setMethodAnnotation(deleteAnnList1);

					methodInfos1.add(updateCtr);

					methodInfos1.add(getCtr);

					methodInfos1.add(addCtr);
					methodInfos1.add(applyCtr);
					methodInfos1.add(deleteCtr);

					List<String> othercontrollerImports = controllerInfo.getOtherImportsList();
					othercontrollerImports.add(FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath())
							.replace(GeneralCreators.ENTITIES, GeneralCreators.SMALL_DTO) + GeneralCreators.DOT
							+ entityInfo.getClassName() + GeneralCreators.DTO);
					// othercontrollerImports.add("org.springframework.beans.factory.annotation.Autowired");

					othercontrollerImports.add("io.swagger.v3.oas.annotations.Hidden");
					controllerInfo.setOtherImportsList(othercontrollerImports);

					List<Field> controllerFields = new ArrayList<Field>();
					Field controllerField = new Field(serviceInfo.getClassName().toLowerCase(),
							serviceInfo.getClassName(),
							serImplCu.getPackageDeclaration().get().toString()
									.replace(GeneralCreators.PACKAGE_SPACE, "").replace(GeneralCreators.SEMICOLON,
											GeneralCreators.DOT + serviceInfo.getClassName()),
							serviceAnnList);
					controllerFields.add(controllerField);
					controllerInfo.setFields(controllerFields);
					controllerInfo.setOtherImportsList(otherContrImports);
					// controllerCreator.createController(entitiesDir, serviceInfo, outputAppPath)
					controllerCreator.createController(initialJavaDir, controllerInfo,
							GeneralCreators.CONTROLLER.toLowerCase());
				} catch (Exception e) {
					e.printStackTrace();
					// TODO: handle exception
				}
			}
			DroolFileProcessor.droolContentProcess(request.rules());
			File folder = new File("com.birlasoft.drools"); 
			FileUtil.refreshFolder(folder);
			FileUtil.refreshFolder(mainDir);
			FileUtil.refreshFolder(mainDir);
			//Application.applicationContext.refresh();
//		    
//			//restartService.restartApp();
			Application.scanAndRegisterBeans("com.birlasoft.*");
			Application.scanAndRegisterBeans("com.birlasoft.drools");
			//restartService.restartApp();
			Utility.buildProject();
			restartService.restartApp();
			
			//
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public byte[] processProject(RequestRecord request) {
		StageInfo stageInfo = StageInfo.getInstance();

		// request is data from client which will have all info for Entity
		ProjectDetail detail = new ProjectDetail();
		detail.setId(1);
		ProjectMetaInfo projectMetaInfo = request.projectMetaInfo();
		List<EntityDetails> listOfEntities = request.listOfEntities();
		detail.setProjectName(projectMetaInfo.name());
		try {
			String temp = projectMetaInfo.name() + new Date().getTime();
			String rootPath = System.getProperty(ProjectSpecificCreators.USER_DIR);
			String outPutDir = FileUtil.getOutPutDirectory(ProjectSpecificCreators.OUTPUT_DIR,
					Integer.parseInt(numberOfProj));
			String outputPath = rootPath + File.separator + outPutDir + File.separator;
			String outputAppPath = outputPath + temp;
			File mainDir = FileUtil.createDirectory(outputAppPath);
			System.out.println(mainDir.getCanonicalPath());
			File initialJavaDir = FileUtil.createDirectory(
					mainDir.getCanonicalPath() + File.separator + ProjectSpecificCreators.SRC_DIR + File.separator
							+ ProjectSpecificCreators.MAIN_DIR + File.separator + ProjectSpecificCreators.JAVA_DIR);
			// Resources directory
			File initialResourcesDir = FileUtil.createDirectory(mainDir.getCanonicalPath() + File.separator
					+ ProjectSpecificCreators.SRC_DIR + File.separator + ProjectSpecificCreators.MAIN_DIR
					+ File.separator + ProjectSpecificCreators.RESOURCES_DIR);
			// Generate resources like application file, swagger file
			resourcesGenerator.generateApplicationProperties(initialResourcesDir);
			// http://localhost:8080/swagger-ui/index.htm
			resourcesGenerator.generateSwagger(initialResourcesDir);

			// test directory
			FileUtil.createDirectory(mainDir.getCanonicalPath() + File.separator + ProjectSpecificCreators.SRC_DIR
					+ File.separator + ProjectSpecificCreators.TEST_DIR);

			// Pom creation
			Pom p = new Pom(projectMetaInfo.group(), projectMetaInfo.artifact(), projectMetaInfo.name(),
					projectMetaInfo.description());
			try {
				pomGenerator.generatePom(mainDir, p);
			} catch (Exception e) {
				CreationStep pom = stageInfo.getPomCreationStep();
				stageInfo.setPomCreationStep(new CreationStep(pom.name(), e.getMessage(), pom.number()));
				e.printStackTrace();
				// return;
			}
			ClassInfo applicationInfo = new ClassInfo();
			applicationInfo.setClassName(GeneralCreators.APPLICATION);

			// set annotation
			List<AnnotationInfo> applicationAnnList = new ArrayList<AnnotationInfo>();
			applicationAnnList.add(new AnnotationInfo(GeneralCreators.SPRING_BOOT_APP, OrgImports.ORG_SPRING_BOOT_APP));
			applicationInfo.setAnnotationList(applicationAnnList);

			// set imports
			List<String> otherApplicationImports = applicationInfo.getOtherImportsList();
			otherApplicationImports.add(OrgImports.ORG_SPRING_APP);
			applicationInfo.setOtherImportsList(otherApplicationImports);

			// set methods
			List<MethodInfo> methodInfosForApplication = applicationInfo.getMethodInfos();
			Keyword key1 = Modifier.Keyword.PUBLIC;
			Keyword[] keys1 = new Keyword[2];
			keys1[0] = key1;

			Keyword key2 = Modifier.Keyword.STATIC;
			keys1[1] = key2;

			MethodInfo mInfo = new MethodInfo(GeneralCreators.MAIN, keys1, new ArrayList<String>());
			mInfo.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);
			List<Parameter> params1 = new ArrayList<MethodInfo.Parameter>();

			params1.add(new Parameter(GeneralCreators.STRING_ARRAY, GeneralCreators.ARGS, null, null));
			mInfo.setParameters(params1);

			methodInfosForApplication.add(mInfo);

			applicationCreator.createApplication(initialJavaDir, applicationInfo, GeneralCreators.SMALL_APPLICATION);

			for (EntityDetails entityDetails : listOfEntities) {

				try {
					// Entity creation And Entity Dto
					ClassInfo entityInfo = new ClassInfo();
					entityInfo.setClassName(entityDetails.name());
					List<AnnotationInfo> entityAnnList = new ArrayList<AnnotationInfo>();
					entityAnnList.add(new AnnotationInfo(
							String.format(ProjectSpecificCreators.TABLE_NAME_ANNO, entityInfo.getClassName()),
							JakartaImports.JAKARTA_TABLE));
					entityAnnList.add(new AnnotationInfo(ProjectSpecificCreators.KEY_NOARGSCONSTRUCTOR,
							ProjectSpecificCreators.VAL_NOARGSCONSTRUCTOR));
					entityAnnList.add(
							new AnnotationInfo(ProjectSpecificCreators.KEY_DATA, ProjectSpecificCreators.VAL_DATA));
					entityAnnList.add(
							new AnnotationInfo(ProjectSpecificCreators.KEY_ENTITY, ProjectSpecificCreators.VAL_ENTITY));
					// @Entity

					entityInfo.setAnnotationList(entityAnnList);
					List<String> entOtherImps = entityInfo.getOtherImportsList();
					List<FieldRecord> inputFields = entityDetails.listOfFields();
					FieldRecord idFieldRec = inputFields.stream().filter(fr -> fr.isId()).findFirst().get();

					List<Field> fields = inputFields.stream().map(fr -> {
						Field field1 = null;
						List<String> field1AnnList = new ArrayList<String>();
						if (fr.isId()) {
							field1AnnList.add(JakartaImports.ID);
							entOtherImps.add(JakartaImports.JAKARTA_ID);
							field1AnnList.add(ProjectSpecificCreators.GENERATED_VAL);
							entOtherImps.add(JakartaImports.JAKARTA_GENERATED_VAL);
							entOtherImps.add(JakartaImports.JAKARTA_GENERATED_TYPE);
							// jakarta.persistence.Column
						} else if (fr.isUnique()) {
							entOtherImps.add(JakartaImports.JAKARTA_COLUMN);
							field1AnnList.add(ProjectSpecificCreators.COLUMN_ANN);
						} else {
							entOtherImps.add(JakartaImports.JAKARTA_COLUMN);
							// field1AnnList.add("Column(unique = false)");
						}

						field1 = new Field(fr.name(), fr.type(),
								FileUtil.getPackageNameByClassName(fr.type()) + "." + fr.type(), field1AnnList);

						return field1;
					}).collect(Collectors.toList());
					entityInfo.setFields(fields);
					entityInfo.setOtherImportsList(entOtherImps);
					String entPath = initialJavaDir.getCanonicalPath() + File.separator
							+ ProjectSpecificCreators.COM_DIR + File.separator + ProjectSpecificCreators.BIRLA_DIR
							+ File.separator + ProjectSpecificCreators.ENTITY_DIR;

					File entitiesDir = FileUtil.createDirectory(entPath);

					entityCreator.createEntity(initialJavaDir, entityInfo, entitiesDir);
					// Repository creation
					ClassInfo repoInfo = new ClassInfo();

					repoInfo.setClassName(entityInfo.getClassName() + ProjectSpecificCreators.REPO_DIR);
					List<ExtendInfo> extendInfos = repoInfo.getExtendInfoList();
					extendInfos.add(new ExtendInfo(
							String.format(GeneralCreators.JPA_REPO, entityInfo.getClassName(), idFieldRec.type()),
							OrgImports.ORG_JPA_REPO));
					repoInfo.setExtendInfoList(extendInfos);
					List<String> otherImports = repoInfo.getOtherImportsList();
					otherImports.add(FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath()) + "."
							+ entityInfo.getClassName());
					repoInfo.setOtherImportsList(otherImports);
					String repoSubDir = GeneralCreators.REPO;

					CompilationUnit cRepo = repoCreator.createRepo(initialJavaDir, repoInfo, repoSubDir);

					// Services creation
					ClassInfo serviceInfo = new ClassInfo();
					serviceInfo.setClassName(entityInfo.getClassName() + GeneralCreators.SERVICE);
					List<String> otherSerImports = repoInfo.getOtherImportsList();
					otherSerImports.add(FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath()) + "."
							+ entityInfo.getClassName());
					repoInfo.setOtherImportsList(otherSerImports);

					List<MethodInfo> methodInfos = serviceInfo.getMethodInfos();
					Keyword k = Modifier.Keyword.PUBLIC;
					Keyword[] keywords = new Keyword[1];
					keywords[0] = k;

					List<Parameter> parameters = new ArrayList<MethodInfo.Parameter>();

					MethodInfo m1 = new MethodInfo(GeneralCreators.SMALL_ADD + entityDetails.name(), keywords,
							new ArrayList<String>());
					
					
					List<String> m1AnnListSer = new ArrayList<String>();
					m1AnnListSer.add(String.format(ProjectSpecificCreators.POST_MAPP_ANN, entityInfo.getClassName().toLowerCase()+"/add"));
					m1AnnListSer.add("Hidden");
					m1.setMethodAnnotation(m1AnnListSer);
					
					parameters.add(new Parameter(entityDetails.name() + GeneralCreators.DTO,
							entityDetails.name().toLowerCase(), null, null));
					m1.setParameters(parameters);
					m1.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);

					MethodInfo m2 = new MethodInfo(GeneralCreators.GET_ALL + entityDetails.name(), keywords,
							new ArrayList<String>());
					m2.setParameters(new ArrayList<MethodInfo.Parameter>());
					m2.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);

					MethodInfo updateService = new MethodInfo(GeneralCreators.UPDATE + entityDetails.name(), keywords,
							new ArrayList<String>());
					updateService.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);
					List<MethodInfo.Parameter> updateServiceParameter = new ArrayList<MethodInfo.Parameter>();

					List<String> updateParaAnnListSer = new ArrayList<String>();
					// updateParaAnnListSer.add("RequestBody");
					List<String> updateParaImportListSer = new ArrayList<String>();
					// updateParaImportListSer.add("org.springframework.web.bind.annotation.RequestBody");

					updateServiceParameter.add(new Parameter(entityDetails.name() + "Dto",
							entityDetails.name().toLowerCase(), updateParaImportListSer, updateParaAnnListSer));
					updateService.setParameters(updateServiceParameter);
					List<String> updatemAnnListSer = new ArrayList<String>();
					updatemAnnListSer.add(String.format(ProjectSpecificCreators.PUT_MAPP_ANN, entityInfo.getClassName().toLowerCase()+"/update"));
					updatemAnnListSer.add("Hidden");
					updateService.setMethodAnnotation(updatemAnnListSer);

					// deleteMapping
					MethodInfo deleteService = new MethodInfo(GeneralCreators.DELETE + entityDetails.name(), keywords,
							new ArrayList<String>());
					deleteService.setMethodReturnType(GeneralCreators.METHOD_VOID);
					List<MethodInfo.Parameter> deleteServiceParameter = new ArrayList<MethodInfo.Parameter>();
					List<String> deleteParaAnnListSer = new ArrayList<String>();
					List<String> deleteParaImportListSer = new ArrayList<String>();

					deleteServiceParameter
							.add(new Parameter(idFieldRec.type(), "id", deleteParaImportListSer, deleteParaAnnListSer));
					deleteService.setParameters(deleteServiceParameter);
					List<String> deleteAnnList1Ser = new ArrayList<String>();
					deleteAnnList1Ser.add(String.format(ProjectSpecificCreators.DEL_MAPP_ANN, entityInfo.getClassName().toLowerCase()+"/delete"));
					deleteAnnList1Ser.add("Hidden");
					deleteService.setMethodAnnotation(deleteAnnList1Ser);

					MethodInfo applyRule = new MethodInfo(GeneralCreators.APPLY + entityDetails.name(), keywords,
							new ArrayList<String>());
//					parameters = new ArrayList<>();
//					parameters.add(new Parameter(entityDetails.name() + GeneralCreators.DTO,
//							entityDetails.name().toLowerCase(), null, null));
					applyRule.setParameters(parameters);
					applyRule.setMethodReturnType(entityDetails.name() + GeneralCreators.DTO);

					methodInfos.add(applyRule);
					methodInfos.add(updateService);
					methodInfos.add(m2);
					methodInfos.add(m1);
					methodInfos.add(deleteService);

					List<String> otherServiceImports = serviceInfo.getOtherImportsList();
					otherServiceImports.add(FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath())
							.replace(GeneralCreators.ENTITIES, GeneralCreators.SMALL_DTO) + "."
							+ entityInfo.getClassName() + GeneralCreators.DTO);
					DroolFileProcessor.processDroolFile("import "+ FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath())
							.replace(GeneralCreators.ENTITIES, GeneralCreators.SMALL_DTO) + "."
							+ entityInfo.getClassName() + GeneralCreators.DTO,true);
					// otherServiceImports.add("org.springframework.beans.factory.annotation.Autowired");
					serviceInfo.setOtherImportsList(otherServiceImports);
					String serviceSubDir = GeneralCreators.SMALL_SERVICE;

					CompilationUnit cService = servicesCreator.createService(initialJavaDir, serviceInfo,
							GeneralCreators.SMALL_SERVICE);
					// Service Impl generation

					List<AnnotationInfo> serviceImplAnnList = new ArrayList<AnnotationInfo>();

					serviceImplAnnList.add(new AnnotationInfo(GeneralCreators.SERVICE, OrgImports.ORG_SPRING_SERVICE));
					serviceInfo.setAnnotationList(serviceImplAnnList);

					List<ExtendInfo> extendInfosService = serviceInfo.getExtendInfoList();
					extendInfosService.add(new ExtendInfo(serviceInfo.getClassName(),
							cService.getPackageDeclaration().get().toString().replace(GeneralCreators.PACKAGE_SPACE, "")
									.replace(GeneralCreators.SEMICOLON,
											GeneralCreators.DOT + serviceInfo.getClassName())));
					serviceInfo.setExtendInfoList(extendInfosService);

					List<Field> serviceFields = new ArrayList<Field>();

					List<String> serviceAnnList = new ArrayList<String>();

					serviceAnnList.add(GeneralCreators.AUTOWIRED);

					Field serviceField = new Field(repoInfo.getClassName().toLowerCase(), repoInfo.getClassName(),
							cRepo.getPackageDeclaration().get().toString().replace(GeneralCreators.PACKAGE_SPACE, "")
									.replace(GeneralCreators.SEMICOLON, GeneralCreators.DOT + repoInfo.getClassName()),
							serviceAnnList);

					Field kaiCotainer = new Field("kieContainer", "KieContainer", "org.kie.api.runtime.KieContainer",
							serviceAnnList);

					serviceFields.add(serviceField);
					serviceFields.add(kaiCotainer);
					serviceInfo.setFields(serviceFields);

					otherServiceImports.add(FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath())
							+ GeneralCreators.DOT + entityInfo.getClassName());
					otherServiceImports.add(OrgImports.ORG_SPRING_AUTOWIRED);
					otherServiceImports.add("org.kie.api.runtime.KieSession");
					serviceInfo.setOtherImportsList(otherServiceImports);
					serviceInfo.setClassName(entityInfo.getClassName() + GeneralCreators.SERVICE_IMPL);

					CompilationUnit serImplCu = servicesCreatorImpl.createServiceImpl(initialJavaDir, serviceInfo,
							GeneralCreators.CAMEL_SERVICE_IMPL);

					// Controller creation

					ClassInfo controllerInfo = new ClassInfo();
					controllerInfo.setClassName(entityInfo.getClassName() + GeneralCreators.CONTROLLER);

					List<AnnotationInfo> controllerAnnList = new ArrayList<AnnotationInfo>();

					controllerAnnList.add(
							new AnnotationInfo(GeneralCreators.REST_CONTROLLER+"(\"/"+controllerInfo.getClassName().toLowerCase()+"\")", OrgImports.ORG_SPRING_RESTCONTROLLER));
					controllerInfo.setAnnotationList(controllerAnnList);

					List<String> otherContrImports = controllerInfo.getOtherImportsList();
					otherContrImports.add(OrgImports.ORG_SPRING_AUTOWIRED);
					otherContrImports.add(OrgImports.ORG_SPRING_POSTMAPPING);
					otherContrImports.add(OrgImports.ORG_SPRING_PUTMAPPING);
					otherContrImports.add(OrgImports.ORG_SPRING_DELETEMAPPING);
					otherContrImports.add(OrgImports.ORG_SPRING_GETMAPPING);

					List<MethodInfo> methodInfos1 = controllerInfo.getMethodInfos();
					Keyword k1 = Modifier.Keyword.PUBLIC;
					Keyword[] keywords1 = new Keyword[1];
					keywords1[0] = k1;
					List<Parameter> parameters1 = new ArrayList<MethodInfo.Parameter>();

					MethodInfo addCtr = new MethodInfo(GeneralCreators.SMALL_ADD + entityDetails.name(), keywords1,
							new ArrayList<String>());
					addCtr.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);
					parameters1.add(new Parameter(entityDetails.name() + GeneralCreators.DTO,
							entityDetails.name().toLowerCase(), null, null));
					addCtr.setParameters(parameters1);
					List<String> mAnnList = new ArrayList<String>();
					mAnnList.add(String.format(ProjectSpecificCreators.POST_MAPP_ANN, entityInfo.getClassName().toLowerCase()+""+GeneralCreators.SMALL_ADD));
					
					mAnnList.add("Hidden");
					
					addCtr.setMethodAnnotation(mAnnList);

					List<Parameter> ruleParameter = new ArrayList<MethodInfo.Parameter>();

					MethodInfo applyCtr = new MethodInfo(GeneralCreators.APPLY + entityDetails.name(), keywords1,
							new ArrayList<String>());
					applyCtr.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);
					ruleParameter.add(new Parameter(entityDetails.name() + GeneralCreators.DTO,
							entityDetails.name().toLowerCase(), null, null));
					applyCtr.setParameters(ruleParameter);
					List<String> applyAnnList = new ArrayList<String>();
					applyAnnList.add(String.format(ProjectSpecificCreators.POST_MAPP_ANN,entityDetails.name().toLowerCase()+"/"+ GeneralCreators.APPLY));
					applyCtr.setMethodAnnotation(applyAnnList);

					MethodInfo getCtr = new MethodInfo(GeneralCreators.GET_ALL + entityDetails.name(), keywords,
							new ArrayList<String>());
					getCtr.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);
					// parameters.add(new Parameter(entityDetails.name() + "Dto",
					// entityDetails.name().toLowerCase(), null, null));
					getCtr.setParameters(new ArrayList<MethodInfo.Parameter>());
					List<String> mAnnList1 = new ArrayList<String>();
					mAnnList1.add(String.format(ProjectSpecificCreators.GET_MAPP_ANN,entityInfo.getClassName().toLowerCase()+"/"+ GeneralCreators.GET_ALL));
					mAnnList1.add("Hidden");
					getCtr.setMethodAnnotation(mAnnList1);

					MethodInfo updateCtr = new MethodInfo(GeneralCreators.UPDATE + entityDetails.name(), keywords,
							new ArrayList<String>());
					updateCtr.setMethodReturnType(GeneralCreators.METHOD_RETURN_OBJECT);
					List<MethodInfo.Parameter> updateCtrParameter = new ArrayList<MethodInfo.Parameter>();

					List<String> updateParaAnnList = new ArrayList<String>();
					// updateParaAnnList.add("RequestBody");
					List<String> updateParaImportList = new ArrayList<String>();
					updateParaImportList.add(OrgImports.ORG_SPRING_REQ_BODY);

					updateCtrParameter.add(new Parameter(entityDetails.name() + GeneralCreators.DTO,
							entityDetails.name().toLowerCase(), updateParaImportList, updateParaAnnList));
					updateCtr.setParameters(updateCtrParameter);
					List<String> updatemAnnList1 = new ArrayList<String>();
					updatemAnnList1.add("PutMapping(\""+entityInfo.getClassName().toLowerCase()+""+"/update\")");
					updatemAnnList1.add("Hidden");
					updateCtr.setMethodAnnotation(updatemAnnList1);

					// deleteMapping
					MethodInfo deleteCtr = new MethodInfo("delete" + entityDetails.name(), keywords,
							new ArrayList<String>());
					deleteCtr.setMethodReturnType(GeneralCreators.METHOD_VOID);
					List<MethodInfo.Parameter> deleteCtrParameter = new ArrayList<MethodInfo.Parameter>();
					List<String> deleteParaAnnList = new ArrayList<String>();
					List<String> deleteParaImportList = new ArrayList<String>();

					deleteCtrParameter
							.add(new Parameter(idFieldRec.type(), "id", deleteParaImportList, deleteParaAnnList));
					deleteCtr.setParameters(deleteCtrParameter);
					List<String> deleteAnnList1 = new ArrayList<String>();
					deleteAnnList1.add(String.format(ProjectSpecificCreators.DEL_MAPP_ANN,entityInfo.getClassName().toLowerCase()+"/"+ "delete"));
					deleteAnnList1.add("Hidden");
					deleteCtr.setMethodAnnotation(deleteAnnList1);

					methodInfos1.add(updateCtr);

					methodInfos1.add(getCtr);

					methodInfos1.add(addCtr);
					methodInfos1.add(applyCtr);
					methodInfos1.add(deleteCtr);

					List<String> othercontrollerImports = controllerInfo.getOtherImportsList();
					othercontrollerImports.add(FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath())
							.replace(GeneralCreators.ENTITIES, GeneralCreators.SMALL_DTO) + GeneralCreators.DOT
							+ entityInfo.getClassName() + GeneralCreators.DTO);
					// othercontrollerImports.add("org.springframework.beans.factory.annotation.Autowired");

					othercontrollerImports.add("io.swagger.v3.oas.annotations.Hidden");
					controllerInfo.setOtherImportsList(othercontrollerImports);

					List<Field> controllerFields = new ArrayList<Field>();
					Field controllerField = new Field(serviceInfo.getClassName().toLowerCase(),
							serviceInfo.getClassName(),
							serImplCu.getPackageDeclaration().get().toString()
									.replace(GeneralCreators.PACKAGE_SPACE, "").replace(GeneralCreators.SEMICOLON,
											GeneralCreators.DOT + serviceInfo.getClassName()),
							serviceAnnList);
					controllerFields.add(controllerField);
					controllerInfo.setFields(controllerFields);
					controllerInfo.setOtherImportsList(otherContrImports);
					// controllerCreator.createController(entitiesDir, serviceInfo, outputAppPath)
					controllerCreator.createController(initialJavaDir, controllerInfo,
							GeneralCreators.CONTROLLER.toLowerCase());

				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
			DroolFileProcessor.droolContentProcess(request.rules());
			File rulesDir = FileUtil.createDirectory(mainDir.getCanonicalPath() + File.separator
					+ ProjectSpecificCreators.SRC_DIR + File.separator + ProjectSpecificCreators.MAIN_DIR
					+ File.separator + ProjectSpecificCreators.RESOURCES_DIR+"/rules");
			resourcesGenerator.generateDrl(rulesDir);
			
			
			
			File confDir = FileUtil.createDirectory(initialJavaDir.getCanonicalPath() + File.separator + ProjectSpecificCreators.COM_DIR
					+ File.separator + ProjectSpecificCreators.BIRLA_DIR + File.separator + GeneralCreators.SMALL_APPLICATION);
			
			
			resourcesGenerator.generateConfigurationJava(confDir);
			File out = FileUtil.createDirectory(outputAppPath);
			return zipeFileProcess(out);
		} catch (Exception e) {
			// TODO: handle exception
		}
		// File initialDir = FileUtil.createDirectory(mainDir.ge);
		return null;
	}

	private static byte[] zipeFileProcess(File fileToZip) {
		FileOutputStream fos;

		try {
			System.out.println(fileToZip.getCanonicalPath());
			fos = new FileOutputStream(fileToZip.getCanonicalPath() + ".zip");

			ZipOutputStream zipOut = new ZipOutputStream(fos);
			// File fileToZip = new File(sourceFile);
			zipFile(fileToZip, fileToZip.getName(), zipOut);
			zipOut.close();
			fos.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			InputStream inputStream;
			try {
				inputStream = new FileInputStream(fileToZip.getCanonicalPath() + ".zip");
				return com.birlasoft.project.utility.Utility.readAllBytes(inputStream);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return null;
	}

	private static void zipFile(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException {
		if (fileToZip.isHidden()) {
			return;
		}
		if (fileToZip.isDirectory()) {
			if (fileName.endsWith("/")) {
				zipOut.putNextEntry(new ZipEntry(fileName));
				zipOut.closeEntry();
			} else {
				zipOut.putNextEntry(new ZipEntry(fileName + "/"));
				zipOut.closeEntry();
			}
			File[] children = fileToZip.listFiles();
			for (File childFile : children) {
				zipFile(childFile, fileName + "/" + childFile.getName(), zipOut);
			}
			return;
		}
		FileInputStream fis = new FileInputStream(fileToZip);
		ZipEntry zipEntry = new ZipEntry(fileName);
		zipOut.putNextEntry(zipEntry);
		byte[] bytes = new byte[1024];
		int length;
		while ((length = fis.read(bytes)) >= 0) {
			zipOut.write(bytes, 0, length);
		}
		fis.close();
	}

}
