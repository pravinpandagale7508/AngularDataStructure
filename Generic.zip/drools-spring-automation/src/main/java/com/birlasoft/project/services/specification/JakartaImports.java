package com.birlasoft.project.services.specification;

public interface JakartaImports {

	// Field Annotation Info

	static String ID = "Id";
	static String JAKARTA_ID = "jakarta.persistence.Id";
	static String JAKARTA_GENERATED_VAL = "jakarta.persistence.GeneratedValue";
	static String JAKARTA_GENERATED_TYPE = "jakarta.persistence.GenerationType";
	static String JAKARTA_COLUMN = "jakarta.persistence.Column";
	static String JAKARTA_TABLE = "jakarta.persistence.Table";
}
