package com.birlasoft.project.services.specification;

public interface ResponseMessages {
	static String DATA_TYPES_FAILURE = "Service Error";
	static String CREATE_PROJECT_SUCCESS = "Project Structure Generated successfully";
	static String CREATE_PROJECT_FAILURE = "Oops..Service Error While Creating Project!!!";
	
}
