package com.birlasoft.project.services.specification;

public interface OrgImports {

	static String ORG_JPA_REPO = "org.springframework.data.jpa.repository.JpaRepository";
	static String ORG_SPRING_SERVICE = "org.springframework.stereotype.Service";
	static String ORG_SPRING_AUTOWIRED = "org.springframework.beans.factory.annotation.Autowired";
	static String ORG_SPRING_RESTCONTROLLER = "org.springframework.web.bind.annotation.RestController";
	static String ORG_SPRING_POSTMAPPING = "org.springframework.web.bind.annotation.PostMapping";
	static String ORG_SPRING_PUTMAPPING = "org.springframework.web.bind.annotation.PutMapping";
	static String ORG_SPRING_DELETEMAPPING = "org.springframework.web.bind.annotation.DeleteMapping";
	static String ORG_SPRING_GETMAPPING = "org.springframework.web.bind.annotation.GetMapping";
	static String ORG_SPRING_BOOT_APP = "org.springframework.boot.autoconfigure.SpringBootApplication";
	static String ORG_SPRING_APP = "org.springframework.boot.SpringApplication";
	static String ORG_SPRING_CODEGEN = "org.openapitools.codegen.languages.SpringCodegen";
	static String ORG_SPRING_REQ_BODY = "org.springframework.web.bind.annotation.RequestBody";
}
