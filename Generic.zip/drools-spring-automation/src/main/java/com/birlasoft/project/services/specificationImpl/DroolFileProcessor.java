package com.birlasoft.project.services.specificationImpl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.birlasoft.project.dto.Pom;
import com.birlasoft.project.services.specification.GeneralCreators;
import com.birlasoft.project.services.specification.ProjectSpecificCreators;
import com.birlasoft.project.utility.FileUtil;
import com.github.javaparser.ast.CompilationUnit;

@Service
public class DroolFileProcessor {
	private static final String RULES_CUSTOMER_RULES_DRL = "rules/customer-discount.drl";

	public static boolean isRuleExist(String s) {
		String dPath = System.getProperty(ProjectSpecificCreators.USER_DIR) + "/src/main/resources/"
				+ RULES_CUSTOMER_RULES_DRL;
//		FileOutputStream fos = new FileOutputStream(dPath, true);
//	    fos.write(s.getBytes());
//	    fos.close();
		File file = new File(dPath); // this is a file handle, s.txt may or may not exist
		boolean found = false;// flag for target txt being present
		try {

			try (BufferedReader br = new BufferedReader(new FileReader(file))) {
				String line;
				while ((line = br.readLine()) != null) { // classic way of reading a file line-by-line
					System.out.println(line);
					if (line.trim().equals(s)) {
						found = true;
						break; // if the text is present, we do not have to read the rest after all
					}
			}
			}catch (Exception e) {
				// TODO: handle exception
			}finally {
				
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return found;
	}

	public static void processDroolFile(String s, boolean checkDuplicate) throws Exception {
//		FileOutputStream out = null;
//		FileInputStream fis = null;
		String dPath = System.getProperty(ProjectSpecificCreators.USER_DIR) + "/src/main/resources/"
				+ RULES_CUSTOMER_RULES_DRL;
//		FileOutputStream fos = new FileOutputStream(dPath, true);
//	    fos.write(s.getBytes());
//	    fos.close();
		File file = new File(dPath); // this is a file handle, s.txt may or may not exist
		boolean found = false;
		if (checkDuplicate) {// flag for target txt being present
			try (BufferedReader br = new BufferedReader(new FileReader(file))) {
				String line;
				while ((line = br.readLine()) != null)
				{// classic way of reading a file line-by-line
					System.out.println(line);
					if (line.equals(s)) {
						found = true;
						break; // if the text is present, we do not have to read the rest after all
					}
				}
			} catch (FileNotFoundException fnfe) {
			}
		}
		if (!found) { // if the text is not found, it has to be written
			try (PrintWriter pw = new PrintWriter(new FileWriter(file, true))) { // it works with
																					// non-existing files too
				pw.println("\n" + s);
			}
		}

	}

	public static void droolContentProcess(List<Map<String, Object>> rules) {
		try {
			DroolFileProcessor.processDroolFile(ProjectSpecificCreators.DROOR_DIALECT, true);
			for (Object rule : rules) {
				Map<String, Object> ruleMap = (Map<String, Object>) rule;

				Map<String, Object> ruleObject = (Map<String, Object>) ruleMap.get("ruleObject");
				String dataObjectName = (String) ruleObject.get("name");
				String dataObjectVariable = dataObjectName.substring(0, 1).toLowerCase() + dataObjectName.substring(1);
				List<Map<String, Object>> conditions = (List<Map<String, Object>>) ruleMap.get("conditions");
				for (Map<String, Object> condition : conditions) {
					String ruleName = (String) condition.get("name");
					String conditionOperator = (String) condition.get("conditionOperator");
					Map<String, Object> whenField = (Map<String, Object>) condition.get("whenField");
					String whenFieldValue = (String) condition.get("whenFieldValue");
					Map<String, Object> thenField = (Map<String, Object>) condition.get("thenField");
					String thenFieldValue = (String) condition.get("thenFieldValue");
					String ruleLine = String.format(ProjectSpecificCreators.DROOR_RULE, ruleName.trim());
					if (!isRuleExist(ruleLine)) {
						DroolFileProcessor.processDroolFile(ruleLine, false);
						// DroolFileProcessor.processDroolFile(String.format(ProjectSpecificCreators.DROOR_RULE,
						// ruleName),false);
						String conditionStr = "";

						if (whenField.get("type").toString().equals("String")) {
							whenFieldValue = "\"" + whenFieldValue + "\"";
						}
						if (thenField.get("type").toString().equals("String")) {
							thenFieldValue = "\"" + thenFieldValue + "\"";
						}

						String cond = dataObjectName + "Dto(" + whenField.get("name").toString() + " "
								+ conditionOperator + " " + whenFieldValue + ")";
						conditionStr = String.format(ProjectSpecificCreators.DROOL_WHEN, dataObjectVariable + "Dto",
								cond);
						DroolFileProcessor.processDroolFile(conditionStr, false);
						String thenFieldName = thenField.get("name").toString();
						String firstLetterCap = thenFieldName.substring(0, 1).toUpperCase()
								+ thenFieldName.substring(1);
						String thenCond = dataObjectVariable + "Dto.set" + firstLetterCap + "(" + thenFieldValue + ");";
						DroolFileProcessor.processDroolFile(String.format(ProjectSpecificCreators.DROOL_THEN, thenCond),
								false);
						DroolFileProcessor.processDroolFile(ProjectSpecificCreators.DROOL_END, false);
					}
					String dPath = System.getProperty(ProjectSpecificCreators.USER_DIR) + "/src/main/resources/"
							;
					FileUtil.refreshFolder(new File(dPath));
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
