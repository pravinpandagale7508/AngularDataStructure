package com.birlasoft.project.services.specification;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import com.birlasoft.project.dto.AnnotationInfo;
import com.birlasoft.project.dto.ClassInfo;
import com.birlasoft.project.dto.Field;
import com.birlasoft.project.utility.FileUtil;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

public abstract class JavaFileCreator {

	public abstract CompilationUnit addClassInterface(CompilationUnit cu, ClassInfo entityInfo);

	public CompilationUnit getCompilationUnit(FileInputStream in) {

		
		ParseResult<CompilationUnit> parceResult = null;
		CompilationUnit cu = null;
		try {
			parceResult = new JavaParser().parse(in);
			cu = parceResult.getResult().get();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return cu;
	}

	public CompilationUnit getCompilationUnitByPath(String path) {
		CompilationUnit cu = null;
		try {
			File newFile = new File(path);

			if (newFile != null) {
				FileInputStream in = new FileInputStream(newFile);

				cu = this.getCompilationUnit(in);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return cu;

	}

	public File processDirectory(File parentDir, ClassInfo entityInfo, String subFolderName) {
		File newFile = null;
		try {
			File entitiesDir = FileUtil.createDirectory(parentDir.getCanonicalPath() + File.separator + "com"
					+ File.separator + ProjectSpecificCreators.BIRLA_DIR + File.separator + subFolderName);

			newFile = FileUtil.createNewFile(
					entitiesDir.getCanonicalFile() + File.separator + entityInfo.getClassName() + ".java");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return newFile;

	}

	public CompilationUnit processPackageName(CompilationUnit cu, File entitiesDir) {
		Name packageName = null;
		try {
			packageName = new Name(FileUtil.getCurrentPackageName(entitiesDir.getCanonicalPath()));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return cu.setPackageDeclaration(new PackageDeclaration(packageName));
	}

	public CompilationUnit processImportStatement(CompilationUnit cu, ClassInfo entityInfo) {
		NodeList<ImportDeclaration> importDeclarationList = new NodeList<>();

		List<Field> listOfFields = entityInfo.getFields();
		for (Field map : listOfFields) {
			importDeclarationList.add(new ImportDeclaration(new Name(map.importSt()), false, false));
		}
		List<AnnotationInfo> annotationInfos = entityInfo.getAnnotationList();
		List<String> importsList = annotationInfos.stream().map(a -> {
			return a.annotationImport();
		}).collect(Collectors.toList());

		for (String imp : importsList) {
			importDeclarationList.add(new ImportDeclaration(new Name(imp), false, false));
		}
		entityInfo.getExtendInfoList().stream().map(e -> e.extendImport()).forEach(s -> {
			importDeclarationList.add(new ImportDeclaration(new Name(s), false, false));
		});
		entityInfo.getOtherImportsList().stream().forEach(s -> {
			importDeclarationList.add(new ImportDeclaration(new Name(s), false, false));
		});
		return cu.setImports(importDeclarationList);
	}

	public CompilationUnit processVisitorAdapter(CompilationUnit cu, Object entityInfo,
			VoidVisitorAdapter<Object> adapter) {
		adapter.visit(cu, entityInfo);
		return cu;
	}

	public CompilationUnit generateJava(File parentDir, ClassInfo entityInfo, File entitiesDir,
			VoidVisitorAdapter<ClassInfo> adapter) {
		FileOutputStream out = null;
		CompilationUnit cu = null;
		try {
			
			File newFile = FileUtil.createNewFile(
					entitiesDir.getCanonicalFile() + File.separator + entityInfo.getClassName() + ".java");
			
			if (newFile != null) {
				FileInputStream in = new FileInputStream(newFile);

				cu = this.getCompilationUnit(in);
				if (cu != null) {
					cu = this.processPackageName(cu, entitiesDir);
					cu = addClassInterface(cu, entityInfo);
					adapter.visit(cu, entityInfo);
					cu = this.processImportStatement(cu, entityInfo);
					out = new FileOutputStream(newFile);
					out.write(cu.toString().getBytes());
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (out != null) {
					out.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return cu;

	}

	public CompilationUnit genrateDto(File initialJavaDir, File entitiesDir, ClassInfo entityInfo,
			VoidVisitorAdapter<Object> adapter) {
		System.out.println("In java file creater class - genrateDto");
		FileOutputStream out = null;
		CompilationUnit cu = null;
		try {
//			File entitiesDir = FileUtil.createDirectory(initialJavaDir.getCanonicalPath() + File.separator + "com"
//					+ File.separator + "birlasoft" + File.separator + "dto");
			File newFile = FileUtil.createNewFile(
					entitiesDir.getCanonicalFile() + File.separator + entityInfo.getClassName() + "Dto.java");

			if (newFile != null) {
				FileInputStream in = new FileInputStream(newFile);

				cu = this.getCompilationUnit(in);
				if (cu != null) {
					cu = this.processPackageName(cu, entitiesDir);
					cu.addClass(entityInfo.getClassName() + "Dto");
					cu = this.processImportStatement(cu, entityInfo);
					adapter.visit(cu, entityInfo);
					// cu = this.processVisitorAdapter(cu, entityInfo, adapter);
					out = new FileOutputStream(newFile);
					out.write(cu.toString().getBytes());
				}

			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (out != null) {
					out.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return cu;
	}
}
