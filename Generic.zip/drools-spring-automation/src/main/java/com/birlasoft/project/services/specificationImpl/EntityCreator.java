package com.birlasoft.project.services.specificationImpl;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.birlasoft.project.dto.AnnotationInfo;
import com.birlasoft.project.dto.ClassInfo;
import com.birlasoft.project.dto.Field;
import com.birlasoft.project.services.specification.GeneralCreators;
import com.birlasoft.project.services.specification.JavaFileCreator;
import com.birlasoft.project.services.specification.ProjectSpecificCreators;
import com.birlasoft.project.utility.FileUtil;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.MarkerAnnotationExpr;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
/**
 * Pravin Pandagale
 */
@Service
public class EntityCreator extends JavaFileCreator {
	
	
	// Generates Entity class
	@SuppressWarnings(ProjectSpecificCreators.UNCHECKED)
	public CompilationUnit createEntity(File parentDir, ClassInfo entityInfo, File entitiesDir) throws IOException {		
		CompilationUnit cu= this.generateJava(parentDir, entityInfo, entitiesDir, new ClassDeclarationVisitor());
		// generates Entity DTO
		File entitiesDir2 = FileUtil.createDirectory(entitiesDir.getCanonicalPath().replace(ProjectSpecificCreators.ENTITY_DIR, "dto"));
		this.genrateDto(parentDir,entitiesDir2, entityInfo, new ClassDtoDeclarationVisitor());
		return cu;

	}
	
	@SuppressWarnings(ProjectSpecificCreators.RAWTYPES)
	private static class ClassDeclarationVisitor extends VoidVisitorAdapter {
		@Override
		public void visit(ClassOrInterfaceDeclaration n, Object arg) {

			ClassInfo entityInfo = (ClassInfo) arg;
			n.setName(entityInfo.getClassName());
			List<Field> listOfFields = entityInfo.getFields();
			for (Field field : listOfFields) {
				FieldDeclaration f = n.addField(field.type(), field.name(), Modifier.Keyword.PRIVATE);
				for (String ann : field.annotationList()) {
					f.addAnnotation(new MarkerAnnotationExpr(new Name(ann)));
				}
			}
			
			NodeList<AnnotationExpr> annotationExprList = new NodeList<>();

			List<AnnotationInfo> annotationInfos = entityInfo.getAnnotationList();
			List<String> annList = annotationInfos.stream().map(a -> {
				return a.annotationName();
			}).collect(Collectors.toList());

			for (String ann : annList) {
				MarkerAnnotationExpr markerAnnotationExpr = new MarkerAnnotationExpr(new Name(ann));
				annotationExprList.add(markerAnnotationExpr);
			}

			n.setAnnotations(annotationExprList);
		}
	}
	
	
	@SuppressWarnings(ProjectSpecificCreators.RAWTYPES)
	private static class ClassDtoDeclarationVisitor extends VoidVisitorAdapter {
		@Override
		public void visit(ClassOrInterfaceDeclaration n, Object arg) {

			ClassInfo entityInfo = (ClassInfo) arg;
			// n.setName(entityInfo.getEntityName().split("\\.")[0]);
			n.setName(entityInfo.getClassName()+GeneralCreators.DTO);
			List<Field> listOfFields = entityInfo.getFields();
			for (Field field : listOfFields) {
				n.addField(field.type(), field.name(), Modifier.Keyword.PRIVATE);
				
			}
			NodeList<AnnotationExpr> annotationExprList = new NodeList<>();
			MarkerAnnotationExpr markerAnnotationExpr = new MarkerAnnotationExpr(new Name(GeneralCreators.DATA));
			annotationExprList.add(markerAnnotationExpr);
			n.setAnnotations(annotationExprList);
		}
	}

	// Defines that generated class is interface or class
	@Override
	public CompilationUnit addClassInterface(CompilationUnit cu, ClassInfo entityInfo) {
		cu.addClass(entityInfo.getClassName());
		return cu;
	}

}
