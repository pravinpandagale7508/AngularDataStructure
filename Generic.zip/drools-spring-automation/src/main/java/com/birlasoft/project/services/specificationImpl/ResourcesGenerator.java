package com.birlasoft.project.services.specificationImpl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.birlasoft.project.dto.AnnotationInfo;
import com.birlasoft.project.dto.ClassInfo;
import com.birlasoft.project.utility.FileUtil;
import com.github.javaparser.ast.CompilationUnit;



@Service
public class ResourcesGenerator {
	
	@Autowired
	EntityCreator entityCreator;
	
	public void generateApplicationProperties(File mainDir) {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try (BufferedReader buffer = new BufferedReader(new FileReader(System.getProperty("user.dir") + "/src/main/resources/application.properties"))) {
			File xml = FileUtil.createNewFile(mainDir.getCanonicalPath() + File.separator + "application.properties");
			System.out.println(System.getProperty("user.dir"));
			fis = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources/application.properties");

			fos = new FileOutputStream(xml);

			String str;
			while ((str = buffer.readLine()) != null) {
				str = str + "\n";
				// if any modification required we can do here
				fos.write(str.getBytes());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
	
	public void generateSwagger(File mainDir) {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try (BufferedReader buffer = new BufferedReader(new FileReader(System.getProperty("user.dir") + "/src/main/resources/swagger.yaml"))) {
			File xml = FileUtil.createNewFile(mainDir.getCanonicalPath() + File.separator + "swagger.yaml");
			System.out.println(System.getProperty("user.dir"));
			fis = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources/swagger.yaml");

			fos = new FileOutputStream(xml);

			String str;
			while ((str = buffer.readLine()) != null) {
				str = str + "\n";				
				fos.write(str.getBytes());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
	
	public void generateDrl(File mainDir) {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try (BufferedReader buffer = new BufferedReader(new FileReader(System.getProperty("user.dir") + "/src/main/resources/rules/customer-discount.drl"))) {
			System.out.println(mainDir.getCanonicalPath() + File.separator + "/customer-discount.drl");
			File xml = FileUtil.createNewFile(mainDir.getCanonicalPath() + File.separator + "/customer-discount.drl");
			System.out.println(System.getProperty("user.dir"));
			fis = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources/rules/customer-discount.drl");

			fos = new FileOutputStream(xml);

			String str;
			while ((str = buffer.readLine()) != null) {
				str = str + "\n";				
				fos.write(str.getBytes());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
	
	public void generateApplicationJava(File mainDir) {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try (BufferedReader buffer = new BufferedReader(new FileReader(System.getProperty("user.dir") + "/src/main/java/com/birlasoft/Application.java"))) {
			File newFile = FileUtil.createNewFile(
					mainDir.getCanonicalFile() + File.separator +   "Application.java");
			System.out.println(System.getProperty("user.dir"));///spring-automation/src/main/java/com/birlasoft/Application.java
			fis = new FileInputStream(System.getProperty("user.dir") + "/src/main/java/com/birlasoft/Application.java");

			fos = new FileOutputStream(newFile);

			String str;
			while ((str = buffer.readLine()) != null) {
				str = str + "\n";
				// if any modification required we can do here
				fos.write(str.getBytes());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
	
	public void generateConfigurationJava(File mainDir) {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try (BufferedReader buffer = new BufferedReader(new FileReader(System.getProperty("user.dir") + "/src/main/java/com/birlasoft/config/DroolsConfig.java"))) {
			File newFile = FileUtil.createNewFile(
					mainDir.getCanonicalFile() + File.separator +   "DroolsConfig.java");
			System.out.println(System.getProperty("user.dir"));///spring-automation/src/main/java/com/birlasoft/Application.java
			fis = new FileInputStream(System.getProperty("user.dir") + "/src/main/java/com/birlasoft/config/DroolsConfig.java");

			fos = new FileOutputStream(newFile);

			String str;
			while ((str = buffer.readLine()) != null) {
				str = str + "\n";
				// if any modification required we can do here
				fos.write(str.getBytes());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
}
