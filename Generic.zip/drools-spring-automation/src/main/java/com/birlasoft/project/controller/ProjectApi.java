package com.birlasoft.project.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;

import com.birlasoft.project.services.specification.GeneralCreators;
import com.birlasoft.project.services.specification.OrgImports;
import com.birlasoft.project.services.specification.ServiceConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Generated;

@Generated(value = OrgImports.ORG_SPRING_CODEGEN, date = ServiceConstants.DATE_DATA_TYPES)
@Validated
@Tag(name = ServiceConstants.PROJECT_NAME_DATA_TYPES, description = ServiceConstants.PROJECT_DISC_DATA_TYPES)
public interface ProjectApi {

	@Operation(operationId = ServiceConstants.OPERATION_ID_DATA_TYPES, summary = ServiceConstants.SUMMERY_DATA_TYPES, tags = { ServiceConstants.PROJECT_NAME_DATA_TYPES }, responses = {
			@ApiResponse(responseCode = ServiceConstants.RESP_CODE_200, description = ServiceConstants.RESP_DISC_DATA_TYPES, content = {
					@Content(mediaType = ServiceConstants.MEDIA_TYPE_DATA_TYPES) }) })
	@GetMapping(ServiceConstants.END_POINT_DATA_TYPES)
	public default Object getDataType() {
		return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

	}
}
