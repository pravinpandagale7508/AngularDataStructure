package com.birlasoft.project;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.birlasoft.project.services.specification.GeneralCreators;
import com.birlasoft.project.services.specification.ProjectSpecificCreators;
import com.birlasoft.project.services.specification.ServiceConstants;
import com.birlasoft.project.utility.DefaultDataType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javaparser.ParseException;


/**
 * @author pravinp14
 */
@Component
public class DefaultDataTypeSeeder implements ApplicationListener<ContextRefreshedEvent> {
    
	/**
	 * @author pravinp14
	 * Auto load all data types from JSON file as soon as application starts.
	 */
    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        this.loadDefaultDataType();
        StageInfo.getInstance();
    }

    private void loadDefaultDataType() {    	
    	String dir = System.getProperty(ProjectSpecificCreators.USER_DIR);
    	JSONParser jsonParser = new JSONParser(); 
		try (FileReader reader = new FileReader(dir + ServiceConstants.DEFAULT_DATA_TYPES_FILE)) {
			Object obj = jsonParser.parse(reader);
			JSONArray categories = (JSONArray) obj;
			DefaultDataType.defaultDataTypes =(List<String>) categories.stream().collect(Collectors.toList());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
    }
}