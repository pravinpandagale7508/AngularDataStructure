package com.birlasoft.project.status;

public enum ProjectStatus 
{
	Success,Pending,Fail
}
