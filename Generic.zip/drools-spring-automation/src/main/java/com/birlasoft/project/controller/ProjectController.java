package com.birlasoft.project.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.KieModule;
import org.kie.api.builder.KieScanner;
import org.kie.api.builder.Message;
import org.kie.api.builder.Results;
import org.kie.api.runtime.KieContainer;
import org.kie.internal.io.ResourceFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.birlasoft.Application;
import com.birlasoft.config.CustomBeanScanner;
import com.birlasoft.project.ModuleManager;
import com.birlasoft.project.ProjectManager;
import com.birlasoft.project.StageInfo;
import com.birlasoft.project.dto.ProjectMetaInfo;
import com.birlasoft.project.dto.ProjectRecord;
import com.birlasoft.project.dto.RequestRecord;
import com.birlasoft.project.services.specification.ProjectSpecificCreators;
import com.birlasoft.project.services.specification.ResponseMessages;
import com.birlasoft.project.services.specification.ServiceConstants;
import com.birlasoft.project.services.specificationImpl.DroolFileProcessor;
import com.birlasoft.project.services.specificationImpl.ZipServicImpl;
import com.birlasoft.project.utility.DefaultDataType;
import com.birlasoft.project.utility.Utility;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@RestController
@Hidden
@RequestMapping(ServiceConstants.END_POINT_PROJECT)
@CrossOrigin(origins = "http://localhost:4200")
public class ProjectController implements ProjectApi {
	@Autowired
	ProjectManager projectManager;
	@Autowired
	ModuleManager moduleManager;
	@Autowired
	ZipServicImpl zipServicImpl;
	@Autowired
	private KieContainer kieContainer;

	@GetMapping("/restart")

	void restart() {
		Thread restartThread = new Thread(() -> {
			try {
				Thread.sleep(1000);
				Application.restart();
			} catch (InterruptedException ignored) {
			}
		});
		restartThread.setDaemon(false);
		restartThread.start();
		// Application.context.refresh();
	}

	@GetMapping(ServiceConstants.END_POINT_DATA_TYPES)
	public Object getDataType() {
		try {
			return new ResponseEntity<>(DefaultDataType.defaultDataTypes, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(ResponseMessages.DATA_TYPES_FAILURE, HttpStatus.FORBIDDEN);
		}
	}

	@PostMapping(value = ServiceConstants.END_POINT_CREATE_PROJECT)
	public Object handleRequest(@RequestBody RequestRecord dto, HttpServletResponse response1) {
		Map<String, Object> response = new HashMap<String, Object>();
		try {
			;
			System.out.println(dto);
			response.put("data", ResponseMessages.CREATE_PROJECT_SUCCESS);
			byte[] bis = null;
			ProjectMetaInfo projectMetaInfo = dto.projectMetaInfo();
			System.out.println(zipServicImpl.getProjectMetaInfo());
//			if (projectMetaInfo.setting().equals("type1")) {
//				bis = projectManager.processProject(dto);
//			} else {
//				bis = moduleManager.processProject(dto);
//			}
			bis = projectManager.processProject(dto);
			if (bis == null) {
				return new ResponseEntity<>("SOME THING WRONG", HttpStatus.FORBIDDEN);
			}

			var headers = new HttpHeaders();
			headers.add("Content-Disposition", "inline; filename=" + "outPut" + "_" + new Date().toString() + ".zip");
			InputStream targetStream = new ByteArrayInputStream(bis);
			return ResponseEntity.ok().headers(headers).contentType(MediaType.parseMediaType("application/zip"))
					.body(new InputStreamResource(targetStream));
		} catch (Exception e) {
			e.printStackTrace();
			response.put("data", ResponseMessages.CREATE_PROJECT_FAILURE);
			return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
		}

	}

	@PostMapping(value = ServiceConstants.END_POINT_DROOL_PROJECT)
	public void handleRequest1(@RequestBody RequestRecord dto, HttpServletResponse response1) {
		Map<String, Object> response = new HashMap<String, Object>();
		try {
			System.out.println(dto.rules());

			projectManager.processDrool(dto);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@GetMapping(ServiceConstants.END_POINT_PROJECT_STATUS)
	public ResponseEntity<StageInfo> getStatus(@RequestBody ProjectRecord dto) {
		return new ResponseEntity<>(StageInfo.getInstance(), HttpStatus.OK);
	}

	@PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Object> upload(@RequestParam("file") MultipartFile file, HttpServletResponse response,
			HttpServletRequest request) {
		try {
			System.out.println(file.getOriginalFilename());
			return new ResponseEntity<>(zipServicImpl.processZipFile(file), HttpStatus.OK);
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
			// TODO: handle exception
		}
		return new ResponseEntity<>(
				new RequestRecord(zipServicImpl.getProjectMetaInfo(), zipServicImpl.getListOfEntityDetails(), null),
				HttpStatus.EXPECTATION_FAILED);
	}

	private static final String RULES_CUSTOMER_RULES_DRL = "rules/customer-discount.drl";

	@GetMapping("/scan")
	public ResponseEntity<Object> scan() {
		try {
			String dPath = System.getProperty(ProjectSpecificCreators.USER_DIR) + "/src/main/resources/"
					+ RULES_CUSTOMER_RULES_DRL;
			System.out.println(dPath);
			KieFileSystem kieFileSystem = KieServices.Factory.get().newKieFileSystem();
			kieFileSystem.write(ResourceFactory.newFileResource(dPath));
			KieBuilder kb = KieServices.Factory.get().newKieBuilder(kieFileSystem);
			kb.buildAll();
			KieModule kieModule = kb.getKieModule();
			kieContainer.updateToVersion(kieModule.getReleaseId());

//	        // Retrieve the bean
//	        //KieContainer kieContainer =Application.context.getBean(KieContainer.class); // Assuming MyBean has a method doSomething()
//
//	        // Dynamically replace the bean with a new instance
//	        BeanDefinitionRegistry registry = (BeanDefinitionRegistry) ((DefaultListableBeanFactory) Application.context.getBeanFactory());
//	        registry.removeBeanDefinition("kieContainer"); // Remove the existing bean definition
//	        
//	        
//	        
//	        Class<?> beanClass = KieContainer.class;
//	       
//	        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(beanClass);
//	        registry.registerBeanDefinition("kieContainer", builder.getBeanDefinition());
//	        //registry.registerBeanDefinition("kieContainer", kieContainer);
//	        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
//	        context.registerBean("kieContainer", KieContainer.class, () -> {
//	        	 KieFileSystem kieFileSystem = KieServices.Factory.get().newKieFileSystem();
//	 	        kieFileSystem.write(ResourceFactory.newFileResource(dPath));
//	 	        KieBuilder kb = KieServices.Factory.get().newKieBuilder(kieFileSystem);
//	 	        kb.buildAll();
//	 	        KieModule kieModule = kb.getKieModule();
//	 	        KieContainer kieContainer = KieServices.Factory.get().newKieContainer(kieModule.getReleaseId());
//	 	        return kieContainer;
//	        });
			scanAndRegisterBeans();

			return new ResponseEntity<>("Success", HttpStatus.OK);
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
			// TODO: handle exception
		}
		return new ResponseEntity<>("Fail", HttpStatus.EXPECTATION_FAILED);
	}

	public static void scanAndRegisterBeans() {
		CustomBeanScanner scanner = new CustomBeanScanner(
				(BeanDefinitionRegistry) Application.context.getBeanFactory());
		scanner.addIncludeFilter(new AnnotationTypeFilter(Configuration.class));

		scanner.scan("com.birlasoft.config");
		// context.refresh(); // Refresh the application context
	}

}
