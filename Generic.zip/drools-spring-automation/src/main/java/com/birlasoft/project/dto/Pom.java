package com.birlasoft.project.dto;

public class Pom {
	private String group;
	private String artifact;
	private String name;
	private String description;
	
	public Pom(String group, String artifact, String name, String description) {
		super();
		this.group = group;
		this.artifact = artifact;
		this.name = name;
		this.description = description;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getArtifact() {
		return artifact;
	}
	public void setArtifact(String artifact) {
		this.artifact = artifact;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
