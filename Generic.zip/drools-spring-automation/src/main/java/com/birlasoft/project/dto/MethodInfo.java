package com.birlasoft.project.dto;

import java.util.ArrayList;
import java.util.List;

import com.github.javaparser.ast.Modifier.Keyword;

public class MethodInfo {
	private String methodName;
	private String methodReturnType;
	
	private Keyword[] methodType;
	private List<String> methodAnnotation = new ArrayList<String>();
	//public record Parameter(String className,String name,String importSt,String annotation) {}
	
	public record Parameter(String className,String name,List<String> importSt,List<String> annotation) {}

	private List<Parameter> parameters = new ArrayList<Parameter>();;
	
	public MethodInfo(String methodName, Keyword[] methodType, List<String> methodAnnotation) {
		super();
		this.methodName = methodName;
		this.methodType = methodType;
		this.methodAnnotation = methodAnnotation;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	public Keyword[] getMethodType() {
		return methodType;
	}
	public void setMethodType(Keyword[] methodType) {
		this.methodType = methodType;
	}
	public List<String> getMethodAnnotation() {
		return methodAnnotation;
	}
	public void setMethodAnnotation(List<String> methodAnnotation) {
		this.methodAnnotation = methodAnnotation;
	}
	public List<Parameter> getParameters() {
		return parameters;
	}
	public void setParameters(List<Parameter> parameters) {
		this.parameters = parameters;
	}
	public String getMethodReturnType() {
		return methodReturnType;
	}
	public void setMethodReturnType(String methodReturnType) {
		this.methodReturnType = methodReturnType;
	}
}
