package com.birlasoft.project.services.specificationImpl;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.birlasoft.project.dto.AnnotationInfo;
import com.birlasoft.project.dto.ClassInfo;
import com.birlasoft.project.dto.Field;
import com.birlasoft.project.services.specification.JavaFileCreator;
import com.birlasoft.project.services.specification.ProjectSpecificCreators;
import com.birlasoft.project.utility.FileUtil;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.MarkerAnnotationExpr;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

@Service
public class ServicesCreator extends JavaFileCreator {

	// Generates service specification
	@SuppressWarnings("unchecked")
	public CompilationUnit createService(File parentDir, ClassInfo serviceInfo, String subFolderName) {

		CompilationUnit cu = null;
		try {
			File serviceDir = FileUtil.createDirectory(parentDir.getCanonicalPath() + File.separator + "com"
					+ File.separator + ProjectSpecificCreators.BIRLA_DIR + File.separator + subFolderName);
			cu = this.generateJava(parentDir, serviceInfo, serviceDir, new ClassDeclarationVisitor());
			// need to add service implementation here

		} catch (IOException e) {
			e.printStackTrace();
		}
		return cu;

	}

	@SuppressWarnings("rawtypes")
	private static class ClassDeclarationVisitor extends VoidVisitorAdapter {
		@Override
		public void visit(ClassOrInterfaceDeclaration n, Object arg) {

			ClassInfo serviceInfo = (ClassInfo) arg;
			n.setName(serviceInfo.getClassName());
			List<Field> listOfFields = serviceInfo.getFields();
			for (Field field : listOfFields) {
				FieldDeclaration f = n.addField(field.type(), field.name(), Modifier.Keyword.PRIVATE);

				for (String ann : field.annotationList()) {
					f.addAnnotation(new MarkerAnnotationExpr(new Name(ann)));
				}
			}

			NodeList<AnnotationExpr> annotationExprList = new NodeList<>();

			List<AnnotationInfo> annotationInfos = serviceInfo.getAnnotationList();
			List<String> annList = annotationInfos.stream().map(a -> {
				return a.annotationName();
			}).collect(Collectors.toList());

			for (String ann : annList) {
				MarkerAnnotationExpr markerAnnotationExpr = new MarkerAnnotationExpr(new Name(ann));
				annotationExprList.add(markerAnnotationExpr);
			}

			n.setAnnotations(annotationExprList);
			NodeList<ClassOrInterfaceType> classOrInterfaceTypes = new NodeList<>();

			serviceInfo.getExtendInfoList().stream().map(e -> e.extendName()).forEach(s -> {
				ClassOrInterfaceType ct = new ClassOrInterfaceType().setName(new SimpleName(s));
				classOrInterfaceTypes.add(ct);
			});

			n.setExtendedTypes(classOrInterfaceTypes);

			serviceInfo.getMethodInfos().stream().forEach(m -> {
				MethodDeclaration methDecl = n.addMethod(m.getMethodName(), m.getMethodType());
				methDecl.setType(m.getMethodReturnType());
				methDecl.removeBody();
//				m.getParameters().stream().forEach(p -> {
//					Parameter p1 = methDecl.addAndGetParameter(p.className(), p.name());
//					if (p.annotation() != null) {
//						p1.addAnnotation(p.annotation());
//					}
//				});
				
				m.getParameters().stream().forEach(p -> {
					Parameter p1 = methDecl.addAndGetParameter(p.className(), p.name());
					if (p.annotation() != null) {
						p.annotation().stream().forEach(pE->{
							p1.addAnnotation(new MarkerAnnotationExpr(new Name(pE)));
						});
					}
				});

			});
		}
	}

	@Override
	public CompilationUnit addClassInterface(CompilationUnit cu, ClassInfo clInfo) {

		cu.addInterface(clInfo.getClassName());
		return cu;
	}

}