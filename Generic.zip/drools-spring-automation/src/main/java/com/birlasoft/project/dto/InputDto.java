package com.birlasoft.project.dto;

import java.util.List;

public class InputDto {
	
	List<FieldRecord> fields;	
	public List<FieldRecord> getFields() {
		return fields;
	}


	public void setFields(List<FieldRecord> fields) {
		this.fields = fields;
	}


	@Override
	public String toString() {
		return "InputDto [fields=" + fields + "]";
	}
	
}
