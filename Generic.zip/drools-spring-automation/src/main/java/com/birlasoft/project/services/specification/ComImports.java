package com.birlasoft.project.services.specification;

public interface ComImports {

	static String COM_OBJECTMAPPER = "com.fasterxml.jackson.databind.ObjectMapper";
}
