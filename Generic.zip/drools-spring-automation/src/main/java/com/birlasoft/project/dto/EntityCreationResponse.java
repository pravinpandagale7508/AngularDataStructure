package com.birlasoft.project.dto;

public record EntityCreationResponse( FieldRecord idFieldRec) {

}
