package com.birlasoft.project.dto;

import java.util.List;

public record ProjectRecord(List<FieldRecord> fields,String projectName,String group,String artifact,String name,String description,String className) {

}
