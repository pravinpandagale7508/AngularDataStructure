package com.birlasoft.project.services.specificationImpl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.birlasoft.project.dto.ClassInfo;
import com.birlasoft.project.dto.Pom;
import com.birlasoft.project.services.specification.GeneralCreators;
import com.birlasoft.project.services.specification.JavaFileCreator;
import com.birlasoft.project.services.specification.ProjectSpecificCreators;
import com.birlasoft.project.utility.FileUtil;
import com.github.javaparser.ast.CompilationUnit;

@Service
public class PomGenerator {
	public void generatePom(File mainDir, Pom pom) throws Exception {
		FileOutputStream out = null;
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try (BufferedReader buffer = new BufferedReader(new FileReader(System.getProperty(ProjectSpecificCreators.USER_DIR) + ProjectSpecificCreators.POM_DIR))) {
			File xml = FileUtil.createNewFile(mainDir.getCanonicalPath() + File.separator + ProjectSpecificCreators.POM_FILE);
			CompilationUnit cu = null;
			System.out.println(System.getProperty(ProjectSpecificCreators.USER_DIR));
			fis = new FileInputStream(System.getProperty(ProjectSpecificCreators.USER_DIR) + ProjectSpecificCreators.POM_DIR);

			fos = new FileOutputStream(xml);

			String str;
			while ((str = buffer.readLine()) != null) {
				// System.out.println(str);
				str = str + GeneralCreators.NEW_LINE;
				//<groupId>com.birlasoft</groupId>
				str = str.replace(ProjectSpecificCreators.GROUP_ID_STR,
						ProjectSpecificCreators.GROUP_ID_OPENTAG + pom.getGroup() + ProjectSpecificCreators.GROUP_ID_CLOSETAG);
				str = str.replace(ProjectSpecificCreators.ARTIFACT_ID_STR,
						ProjectSpecificCreators.ARTIFACT_ID_OPENTAG + pom.getArtifact() + ProjectSpecificCreators.ARTIFACT_ID_CLOSETAG);
				str = str.replace(ProjectSpecificCreators.NAME_STR,
						ProjectSpecificCreators.NAME_OPENTAG + pom.getName() + ProjectSpecificCreators.NAME_CLOSETAG);
				str = str.replace(ProjectSpecificCreators.DESC_STR,
						ProjectSpecificCreators.DESC_OPENTAG + pom.getDescription() + ProjectSpecificCreators.DESC_CLOSETAG);
				
				fos.write(str.getBytes());
				// builder.append(str).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
	public void generateMainPom(File mainDir, Pom pom,List<String> modules) throws Exception {
		FileOutputStream out = null;
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try (BufferedReader buffer = new BufferedReader(new FileReader(System.getProperty(ProjectSpecificCreators.USER_DIR)+"/src/main/resources/pomModuleTemp.xml"))) {
			File xml = FileUtil.createNewFile(mainDir.getCanonicalPath() + File.separator + ProjectSpecificCreators.POM_FILE);
			CompilationUnit cu = null;
			System.out.println(System.getProperty(ProjectSpecificCreators.USER_DIR));
			fis = new FileInputStream(System.getProperty(ProjectSpecificCreators.USER_DIR)+"/src/main/resources/pomModuleTemp.xml");

			fos = new FileOutputStream(xml);

			String str;
			while ((str = buffer.readLine()) != null) {
				 System.out.println(str);
				 if(str.trim().equals("<modules>")) {
						for(String s:modules) {
							str = str + GeneralCreators.NEW_LINE+"<module>" + s +"</module>"+ GeneralCreators.NEW_LINE;
						}
					}
				str = str + GeneralCreators.NEW_LINE;
				//<groupId>com.birlasoft</groupId>
				str = str.replace(ProjectSpecificCreators.GROUP_ID_STR,
						ProjectSpecificCreators.GROUP_ID_OPENTAG + pom.getGroup() + ProjectSpecificCreators.GROUP_ID_CLOSETAG);
				str = str.replace("<artifactId>UTCL-MAIN</artifactId>",
						ProjectSpecificCreators.ARTIFACT_ID_OPENTAG + pom.getArtifact() + ProjectSpecificCreators.ARTIFACT_ID_CLOSETAG);
				str = str.replace(ProjectSpecificCreators.NAME_STR,
						ProjectSpecificCreators.NAME_OPENTAG + pom.getName() + ProjectSpecificCreators.NAME_CLOSETAG);
				str = str.replace(ProjectSpecificCreators.DESC_STR,
						ProjectSpecificCreators.DESC_OPENTAG + pom.getDescription() + ProjectSpecificCreators.DESC_CLOSETAG);
				
				fos.write(str.getBytes());
				// builder.append(str).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
}
