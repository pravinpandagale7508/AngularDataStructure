package com.birlasoft.project.dto;

import com.github.javaparser.ast.CompilationUnit;

public record CompilationRecord(String name,CompilationUnit compilationUnit) {

}
