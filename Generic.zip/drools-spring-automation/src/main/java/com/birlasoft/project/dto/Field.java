package com.birlasoft.project.dto;

import java.util.List;

public record Field(String name,String type,String importSt,List<String> annotationList) {}
