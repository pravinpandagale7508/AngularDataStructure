package com.birlasoft.project.dto;

import com.birlasoft.project.status.ProjectStatus;

import lombok.Data;

//@Data
public class ProjectDetail {
	private int id;
	private String projectName;
	private ProjectStatus projectStatus;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public ProjectStatus getProjectStatus() {
		return projectStatus;
	}
	public void setProjectStatus(ProjectStatus projectStatus) {
		this.projectStatus = projectStatus;
	}
	
}
