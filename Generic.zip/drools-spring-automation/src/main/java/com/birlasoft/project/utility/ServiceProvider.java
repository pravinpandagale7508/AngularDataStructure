package com.birlasoft.project.utility;

import java.util.ServiceLoader;

import com.birlasoft.Application;

public abstract class ServiceProvider {
   public static Application getDefault() {

      // load our plugin
      ServiceLoader<Application> serviceLoader =
         ServiceLoader.load(Application.class);

      // reload the service
      System.out.println("Reloading...");
      serviceLoader.reload();
      System.out.println("Reloaded.");

      // checking if load was successful
      for (Application provider : serviceLoader) {
         return provider;
      }
      throw new Error("Something is wrong with registering the addon");
   }
}