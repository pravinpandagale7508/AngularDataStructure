package com.birlasoft.project.services.specification.functional;

@FunctionalInterface
public interface CallBackId {
	public Long getId();
}
