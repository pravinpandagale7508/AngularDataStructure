package com.birlasoft.project.dto;

public record FieldRecord(String name, String type, boolean isId, boolean isUnique, boolean isNull) {}
