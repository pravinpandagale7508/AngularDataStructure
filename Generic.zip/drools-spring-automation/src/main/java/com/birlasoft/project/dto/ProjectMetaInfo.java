package com.birlasoft.project.dto;

public record ProjectMetaInfo(String group,String artifact,String name,String description,String setting) {

}
