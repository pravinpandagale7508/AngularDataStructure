package com.birlasoft.project.dto;

public record AnnotationInfo(String annotationName,String annotationImport) {}
//public class AnnotationInfo {
//	private String annotationName;
//	private String annotationImport;
//	public AnnotationInfo(String annotationName, String annotationImport) {
//		super();
//		this.annotationName = annotationName;
//		this.annotationImport = annotationImport;
//	}
//	public String getAnnotationName() {
//		return annotationName;
//	}
//	public void setAnnotationName(String annotationName) {
//		this.annotationName = annotationName;
//	}
//	public String getAnnotationImport() {
//		return annotationImport;
//	}
//	public void setAnnotationImport(String annotationImport) {
//		this.annotationImport = annotationImport;
//	}
//	
//}
