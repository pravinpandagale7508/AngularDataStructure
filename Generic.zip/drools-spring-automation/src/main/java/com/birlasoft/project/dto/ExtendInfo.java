package com.birlasoft.project.dto;

public record ExtendInfo(String extendName,String extendImport) {}
//public class ExtendInfo {
//	private String extendName;
//	private String extendImport;
//	public ExtendInfo(String extendName, String extendImport) {
//		super();
//		this.extendName = extendName;
//		this.extendImport = extendImport;
//	}
//	public String getExtendName() {
//		return extendName;
//	}
//	public void setExtendName(String extendName) {
//		this.extendName = extendName;
//	}
//	public String getExtendImport() {
//		return extendImport;
//	}
//	public void setExtendImport(String extendImport) {
//		this.extendImport = extendImport;
//	}
//	
//}
