package com.birlasoft.project.dto;

public record CreationStep(String name,String message,Integer number) {

}
