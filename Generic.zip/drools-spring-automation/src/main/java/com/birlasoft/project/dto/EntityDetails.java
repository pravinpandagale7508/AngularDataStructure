package com.birlasoft.project.dto;

import java.util.List;

public record EntityDetails(Long id,String name,List<FieldRecord> listOfFields,String originalName) {

}
