package com.birlasoft.project.utility;

import java.util.ArrayList;
import java.util.List;

public class DefaultDataType {
	public static List<String> defaultDataTypes = new ArrayList<String>();
}
