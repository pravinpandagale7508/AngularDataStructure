package com.birlasoft;

import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;

import com.birlasoft.config.CustomBeanScanner;

/**
 * @author pravinp14
 * @apiNote
 */
@SpringBootApplication
@ComponentScan(basePackages = { "com.birlasoft.*"})
public class Application {
	private static String[] args;
	public static ConfigurableApplicationContext context;

	public static void main(String[] args) {
		Application.args = args;
		Application.context = SpringApplication.run(Application.class, args);
		
	}
	public static void restart() {
	    // close previous context
	    if(Application.context!=null) {
	    	Application.context.refresh();
	    	Application.context.stop();
	    }
	   
	    // and build new one
	    Application.context = SpringApplication.run(Application.class, args);

	}
	public  static void scanAndRegisterBeans(String basePackage) {
        CustomBeanScanner scanner = new CustomBeanScanner((BeanDefinitionRegistry) context.getBeanFactory());
        scanner.addIncludeFilter(new AnnotationTypeFilter(Component.class));
        scanner.addIncludeFilter(new AnnotationTypeFilter(Controller.class));
        scanner.addIncludeFilter(new AnnotationTypeFilter(RestController.class));
        scanner.addIncludeFilter(new AnnotationTypeFilter(Service.class));
        scanner.scan(basePackage);
        //context.refresh(); // Refresh the application context
    }
}
