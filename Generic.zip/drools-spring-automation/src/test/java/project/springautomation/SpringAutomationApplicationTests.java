package project.springautomation;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import com.birlasoft.Application;
import com.birlasoft.project.ProjectManager;

@ComponentScan(basePackages = { "com.birlasoft" })
@SpringBootTest(classes = { Application.class })
class SpringAutomationApplicationTests {
	@Autowired
	ProjectManager manager;

	@Test
	void contextLoads() {
	}

	@Test
	void createProject() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("projectName", "New");
		map.put("group", "com.example");
		map.put("artifact", "demo");
		map.put("name", "demo");
		map.put("description", "Demo project for Spring Boot");
		map.put("className", "Employee");
		//manager.processProject(map);
	}

}
