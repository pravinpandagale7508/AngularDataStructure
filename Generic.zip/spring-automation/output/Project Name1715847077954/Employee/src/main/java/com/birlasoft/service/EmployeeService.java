package com.birlasoft.service;

import com.birlasoft.dto.EmployeeDto;

public interface EmployeeService {

    public Object updateEmployee(EmployeeDto employee);

    public Object getAllEmployee();

    public Object addEmployee(EmployeeDto employee);

    public void deleteEmployee(Long id);
}
