package com.birlasoft.entities;

import java.lang.Long;
import java.lang.String;
import jakarta.persistence.Table;
import lombok.NoArgsConstructor;
import lombok.Data;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Column;

@Table(name = "Employee")
@NoArgsConstructor
@Data
@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long name;

    @Column(unique = true)
    private String address;
}
