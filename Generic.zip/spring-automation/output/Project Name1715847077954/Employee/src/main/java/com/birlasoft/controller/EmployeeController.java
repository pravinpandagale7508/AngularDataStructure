package com.birlasoft.controller;

import com.birlasoft.serviceImpl.EmployeeServiceImpl

;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import com.birlasoft.dto.EmployeeDto;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeServiceImpl employeeserviceimpl;

    @PutMapping("/update")
    public Object updateEmployee(EmployeeDto employee) {
        return employeeserviceimpl.updateEmployee(employee);
    }

    @GetMapping("/getAll")
    public Object getAllEmployee() {
        return employeeserviceimpl.getAllEmployee();
    }

    @PostMapping("/add")
    public Object addEmployee(EmployeeDto employee) {
        return employeeserviceimpl.addEmployee(employee);
    }

    @DeleteMapping("/delete")
    public void deleteEmployee(Long id) {
        employeeserviceimpl.deleteEmployee(id);
    }
}
