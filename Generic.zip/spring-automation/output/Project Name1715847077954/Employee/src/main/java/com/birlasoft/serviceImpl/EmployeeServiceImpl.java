package com.birlasoft.serviceImpl;

import com.birlasoft.repository.EmployeeRepo

;
import org.springframework.stereotype.Service;
import com.birlasoft.service.EmployeeService

;
import com.birlasoft.dto.EmployeeDto;
import com.birlasoft.entities.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepo employeerepo;

    public Object updateEmployee(EmployeeDto employee) {
        return employeerepo.save(new ObjectMapper().convertValue(employee, Employee.class));
    }

    public Object getAllEmployee() {
        return employeerepo.findAll();
    }

    public Object addEmployee(EmployeeDto employee) {
        return employeerepo.save(new ObjectMapper().convertValue(employee, Employee.class));
    }

    public void deleteEmployee(Long id) {
         employeerepo.deleteById(id);
    }
}
