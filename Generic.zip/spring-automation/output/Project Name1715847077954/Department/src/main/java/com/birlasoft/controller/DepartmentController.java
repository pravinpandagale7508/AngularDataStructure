package com.birlasoft.controller;

import com.birlasoft.serviceImpl.DepartmentServiceImpl

;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import com.birlasoft.dto.DepartmentDto;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class DepartmentController {

    @Autowired
    private DepartmentServiceImpl departmentserviceimpl;

    @PutMapping("/update")
    public Object updateDepartment(DepartmentDto department) {
        return departmentserviceimpl.updateDepartment(department);
    }

    @GetMapping("/getAll")
    public Object getAllDepartment() {
        return departmentserviceimpl.getAllDepartment();
    }

    @PostMapping("/add")
    public Object addDepartment(DepartmentDto department) {
        return departmentserviceimpl.addDepartment(department);
    }

    @DeleteMapping("/delete")
    public void deleteDepartment(Integer id) {
        departmentserviceimpl.deleteDepartment(id);
    }
}
