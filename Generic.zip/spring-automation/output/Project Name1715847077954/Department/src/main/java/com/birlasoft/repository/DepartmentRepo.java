package com.birlasoft.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.birlasoft.entities.Department;

public interface DepartmentRepo extends JpaRepository<Department, Integer> {
}
