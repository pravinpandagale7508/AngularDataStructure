package com.birlasoft.service;

import com.birlasoft.dto.DepartmentDto;

public interface DepartmentService {

    public Object updateDepartment(DepartmentDto department);

    public Object getAllDepartment();

    public Object addDepartment(DepartmentDto department);

    public void deleteDepartment(Integer id);
}
