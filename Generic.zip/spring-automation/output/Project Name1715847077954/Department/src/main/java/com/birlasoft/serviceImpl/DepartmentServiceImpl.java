package com.birlasoft.serviceImpl;

import com.birlasoft.repository.DepartmentRepo

;
import org.springframework.stereotype.Service;
import com.birlasoft.service.DepartmentService

;
import com.birlasoft.dto.DepartmentDto;
import com.birlasoft.entities.Department;
import org.springframework.beans.factory.annotation.Autowired;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    private DepartmentRepo departmentrepo;

    public Object updateDepartment(DepartmentDto department) {
        return departmentrepo.save(new ObjectMapper().convertValue(department, Department.class));
    }

    public Object getAllDepartment() {
        return departmentrepo.findAll();
    }

    public Object addDepartment(DepartmentDto department) {
        return departmentrepo.save(new ObjectMapper().convertValue(department, Department.class));
    }

    public void deleteDepartment(Integer id) {
         departmentrepo.deleteById(id);
    }
}
