package com.birlasoft.entities;

import java.lang.Integer;
import jakarta.persistence.Table;
import lombok.NoArgsConstructor;
import lombok.Data;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

@Table(name = "WW")
@NoArgsConstructor
@Data
@Entity
public class WW {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
}
