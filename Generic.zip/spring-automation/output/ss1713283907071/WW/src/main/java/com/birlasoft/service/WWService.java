package com.birlasoft.service;

import com.birlasoft.dto.WWDto;

public interface WWService {

    public Object updateWW(WWDto ww);

    public Object getAllWW();

    public Object addWW(WWDto ww);

    public void deleteWW(Integer id);
}
