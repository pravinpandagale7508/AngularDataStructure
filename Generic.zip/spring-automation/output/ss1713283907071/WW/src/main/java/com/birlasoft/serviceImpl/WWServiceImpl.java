package com.birlasoft.serviceImpl;

import com.birlasoft.repository.WWRepo

;
import org.springframework.stereotype.Service;
import com.birlasoft.service.WWService

;
import com.birlasoft.dto.WWDto;
import com.birlasoft.entities.WW;
import org.springframework.beans.factory.annotation.Autowired;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class WWServiceImpl implements WWService {

    @Autowired
    private WWRepo wwrepo;

    public Object updateWW(WWDto ww) {
        return wwrepo.save(new ObjectMapper().convertValue(ww, WW.class));
    }

    public Object getAllWW() {
        return wwrepo.findAll();
    }

    public Object addWW(WWDto ww) {
        return wwrepo.save(new ObjectMapper().convertValue(ww, WW.class));
    }

    public void deleteWW(Integer id) {
         wwrepo.deleteById(id);
    }
}
