package com.birlasoft.dto;

import java.lang.Integer;
import jakarta.persistence.Table;
import lombok.NoArgsConstructor;
import lombok.Data;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

@Data
public class WWDto {

    private Integer id;
}
