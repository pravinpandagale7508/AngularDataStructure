package com.birlasoft.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.birlasoft.entities.WW;

public interface WWRepo extends JpaRepository<WW, Integer> {
}
