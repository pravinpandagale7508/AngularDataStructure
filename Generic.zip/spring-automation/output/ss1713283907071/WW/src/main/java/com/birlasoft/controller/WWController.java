package com.birlasoft.controller;

import com.birlasoft.serviceImpl.WWServiceImpl

;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import com.birlasoft.dto.WWDto;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class WWController {

    @Autowired
    private WWServiceImpl wwserviceimpl;

    @PutMapping("/update")
    public Object updateWW(WWDto ww) {
        return wwserviceimpl.updateWW(ww);
    }

    @GetMapping("/getAll")
    public Object getAllWW() {
        return wwserviceimpl.getAllWW();
    }

    @PostMapping("/add")
    public Object addWW(WWDto ww) {
        return wwserviceimpl.addWW(ww);
    }

    @DeleteMapping("/delete")
    public void deleteWW(Integer id) {
        wwserviceimpl.deleteWW(id);
    }
}
