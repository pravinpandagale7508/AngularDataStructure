package com.birlasoft.service;

import com.birlasoft.dto.PlanDto;

public interface PlanService {

    public Object updatePlan(PlanDto plan);

    public Object getAllPlan();

    public Object addPlan(PlanDto plan);

    public void deletePlan(Integer id);
}
