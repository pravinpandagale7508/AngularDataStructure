package com.birlasoft.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.birlasoft.entities.Plan;

public interface PlanRepo extends JpaRepository<Plan, Integer> {
}
