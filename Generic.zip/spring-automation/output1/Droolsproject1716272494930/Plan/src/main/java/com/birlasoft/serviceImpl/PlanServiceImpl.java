package com.birlasoft.serviceImpl;

import com.birlasoft.repository.PlanRepo

;
import org.springframework.stereotype.Service;
import com.birlasoft.service.PlanService

;
import com.birlasoft.dto.PlanDto;
import com.birlasoft.entities.Plan;
import org.springframework.beans.factory.annotation.Autowired;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class PlanServiceImpl implements PlanService {

    @Autowired
    private PlanRepo planrepo;

    public Object updatePlan(PlanDto plan) {
        return planrepo.save(new ObjectMapper().convertValue(plan, Plan.class));
    }

    public Object getAllPlan() {
        return planrepo.findAll();
    }

    public Object addPlan(PlanDto plan) {
        return planrepo.save(new ObjectMapper().convertValue(plan, Plan.class));
    }

    public void deletePlan(Integer id) {
         planrepo.deleteById(id);
    }
}
