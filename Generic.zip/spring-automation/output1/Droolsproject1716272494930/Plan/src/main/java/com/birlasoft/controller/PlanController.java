package com.birlasoft.controller;

import com.birlasoft.serviceImpl.PlanServiceImpl

;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import com.birlasoft.dto.PlanDto;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class PlanController {

    @Autowired
    private PlanServiceImpl planserviceimpl;

    @PutMapping("/update")
    public Object updatePlan(PlanDto plan) {
        return planserviceimpl.updatePlan(plan);
    }

    @GetMapping("/getAll")
    public Object getAllPlan() {
        return planserviceimpl.getAllPlan();
    }

    @PostMapping("/add")
    public Object addPlan(PlanDto plan) {
        return planserviceimpl.addPlan(plan);
    }

    @DeleteMapping("/delete")
    public void deletePlan(Integer id) {
        planserviceimpl.deletePlan(id);
    }
}
