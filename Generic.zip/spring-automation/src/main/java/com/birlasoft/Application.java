package com.birlasoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.birlasoft.project.ProjectManager;
import com.birlasoft.project.controller.ProjectController;

/**
 * @author pravinp14
 * @apiNote
 */
@SpringBootApplication
public class Application {
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
	}
}
