package com.birlasoft.project.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.birlasoft.project.ModuleManager;
import com.birlasoft.project.ProjectManager;
import com.birlasoft.project.StageInfo;
import com.birlasoft.project.dto.InputDto;
import com.birlasoft.project.dto.ProjectMetaInfo;
import com.birlasoft.project.dto.ProjectRecord;
import com.birlasoft.project.dto.RequestRecord;
import com.birlasoft.project.services.specification.ResponseMessages;
import com.birlasoft.project.services.specification.ServiceConstants;
import com.birlasoft.project.services.specificationImpl.ZipServicImpl;
import com.birlasoft.project.utility.DefaultDataType;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping(ServiceConstants.END_POINT_PROJECT)
@CrossOrigin(origins = "http://localhost:4200")

public class ProjectController implements ProjectApi {
	@Autowired
	ProjectManager projectManager;
	@Autowired
	ModuleManager moduleManager;
	@Autowired
	ZipServicImpl zipServicImpl;

	@GetMapping(ServiceConstants.END_POINT_DATA_TYPES)
	public Object getDataType() {
		try {
			return new ResponseEntity<>(DefaultDataType.defaultDataTypes, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(ResponseMessages.DATA_TYPES_FAILURE, HttpStatus.FORBIDDEN);
		}
	}

	@PostMapping(value = ServiceConstants.END_POINT_CREATE_PROJECT)
	public Object handleRequest(@RequestBody RequestRecord dto, HttpServletResponse response1) {
		Map<String, Object> response = new HashMap<String, Object>();
		try {
			;
			System.out.println(dto);
			response.put("data", ResponseMessages.CREATE_PROJECT_SUCCESS);
			byte[] bis = null;
			ProjectMetaInfo projectMetaInfo = dto.projectMetaInfo();
			System.out.println(zipServicImpl.getProjectMetaInfo());
			if (projectMetaInfo.setting().equals("type1")) {
				bis = projectManager.processProject(dto);
			} else {
				bis = moduleManager.processProject(dto);
			}
			if (bis == null) {
				return new ResponseEntity<>("SOME THING WRONG", HttpStatus.FORBIDDEN);
			}

			var headers = new HttpHeaders();
			headers.add("Content-Disposition", "inline; filename=" + "outPut" + "_" + new Date().toString() + ".zip");
			InputStream targetStream = new ByteArrayInputStream(bis);
			return ResponseEntity.ok().headers(headers).contentType(MediaType.parseMediaType("application/zip"))
					.body(new InputStreamResource(targetStream));
		} catch (Exception e) {
			e.printStackTrace();
			response.put("data", ResponseMessages.CREATE_PROJECT_FAILURE);
			return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
		}

	}

	@GetMapping(ServiceConstants.END_POINT_PROJECT_STATUS)
	public ResponseEntity<StageInfo> getStatus(@RequestBody ProjectRecord dto) {
		return new ResponseEntity<>(StageInfo.getInstance(), HttpStatus.OK);
	}

	@PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Object> upload(@RequestParam("file") MultipartFile file, HttpServletResponse response,
			HttpServletRequest request) {
		try {
			System.out.println(file.getOriginalFilename());
			return new ResponseEntity<>(zipServicImpl.processZipFile(file), HttpStatus.OK);
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
			// TODO: handle exception
		}
		return new ResponseEntity<>(new RequestRecord(zipServicImpl.getProjectMetaInfo(), zipServicImpl.getListOfEntityDetails()), HttpStatus.EXPECTATION_FAILED);
	}

}
