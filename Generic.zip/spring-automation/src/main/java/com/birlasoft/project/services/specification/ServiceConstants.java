package com.birlasoft.project.services.specification;

public interface ServiceConstants {
	//getDataTypes Constants
	
	static String DEFAULT_DATA_TYPES_FILE = "/DefaultDataType.json";
	static String DATE_DATA_TYPES = "2024-02-14T14:36:54.109884400+05:30[Asia/Calcutta]";
	static String PROJECT_NAME_DATA_TYPES = "Project";
	static String PROJECT_DISC_DATA_TYPES = "the Project API";
	static String OPERATION_ID_DATA_TYPES = "getDataType";
	static String END_POINT_DATA_TYPES = "/getDataType";
	static String SUMMERY_DATA_TYPES = "List of default data types.";
	static String RESP_CODE_200 = "200";
	static String RESP_DISC_DATA_TYPES = "Literally returns List of default data types.";
	static String MEDIA_TYPE_DATA_TYPES = "application/json";
	
	
	static String END_POINT_PROJECT = "/project";
	static String END_POINT_CREATE_PROJECT = "/createProject";
	static String END_POINT_PROJECT_STATUS = "/getStatus";
}
