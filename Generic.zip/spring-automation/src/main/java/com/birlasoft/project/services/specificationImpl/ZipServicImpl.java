package com.birlasoft.project.services.specificationImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.birlasoft.project.dto.ClassInfo;
import com.birlasoft.project.dto.CompilationRecord;
import com.birlasoft.project.dto.EntityDetails;
import com.birlasoft.project.dto.Field;
import com.birlasoft.project.dto.FieldRecord;
import com.birlasoft.project.dto.ProjectMetaInfo;
import com.birlasoft.project.dto.RequestRecord;
import com.birlasoft.project.services.specification.GeneralCreators;
import com.birlasoft.project.services.specification.JakartaImports;
import com.birlasoft.project.services.specification.ProjectSpecificCreators;
import com.birlasoft.project.services.specification.functional.CallBackEntityDetails;
import com.birlasoft.project.services.specification.functional.CallBackId;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.DataKey;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.MarkerAnnotationExpr;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

@Service
public class ZipServicImpl {
	private List<CompilationRecord> listOfCompilationUnit = new ArrayList<CompilationRecord>();
	private ProjectMetaInfo projectMetaInfo;
	private List<EntityDetails> listOfEntityDetails = new ArrayList<EntityDetails>();
	Long id = 0L;

	public List<CompilationRecord> getListOfCompilationUnit() {
		return listOfCompilationUnit;
	}

	public ProjectMetaInfo getProjectMetaInfo() {
		return projectMetaInfo;
	}

	public List<EntityDetails> getListOfEntityDetails() {
		return listOfEntityDetails;
	}

	public RequestRecord processZipFile(MultipartFile file) {
		try {
			id = 0L;
			// //System.out.println(file.getOriginalFilename());
			this.listOfEntityDetails = new ArrayList<EntityDetails>();
			String group = "";
			String artifact = "";
			String name = "";
			String description = "";
			String setting = "";
			int numOfXmls = 0;
			File destDir = new File("src/main/resources/unzipTest");
			FileUtils.cleanDirectory(destDir); // clean out directory (this is optional -- but good know)
			FileUtils.forceDelete(destDir); // delete directory
			FileUtils.forceMkdir(destDir);
			byte[] buffer = new byte[1024];
			ZipInputStream zis = new ZipInputStream(file.getInputStream());
			ZipEntry zipEntry = zis.getNextEntry();
			while (zipEntry != null) {
				File newFile = newFile(destDir, zipEntry);
				if (zipEntry.isDirectory()) {
					if (!newFile.isDirectory() && !newFile.mkdirs()) {
						throw new IOException("Failed to create directory " + newFile);
					}
				} else {
					// fix for Windows-created archives
					File parent = newFile.getParentFile();
					if (!parent.isDirectory() && !parent.mkdirs()) {
						throw new IOException("Failed to create directory " + parent);
					}
					// write file content
					FileOutputStream fos = new FileOutputStream(newFile);
					int len;
					while ((len = zis.read(buffer)) > 0) {
						fos.write(buffer, 0, len);
					}
					fos.close();
					
					if (FilenameUtils.getExtension(newFile.getName()).equals("java")) {
						CompilationUnit cu = this.getCompilationUnit(new FileInputStream(newFile));
						//id = 0L;
						//String packageName = cu.getPackageDeclaration().orElseThrow().getName().asString();
						if (cu.toString().contains("@Entity")) {
							// if (packageName.equals("com.birlasoft.entities")) {
							CallBackId callBack = () -> ++id;
							CallBackEntityDetails backEntityDetails = (e) -> {
								this.listOfEntityDetails.add(e);
							};
							Map<String, Object> data = new HashMap<String, Object>();
							data.put("CALL_ID", callBack);
							data.put("CALL_ENTITY", backEntityDetails);
							cu.accept(new ClassDtoDeclarationVisitor(), data);
						}

						this.listOfCompilationUnit.add(new CompilationRecord(newFile.getName(), cu));
					} else if (FilenameUtils.getExtension(newFile.getName()).equals("xml")) {
						numOfXmls++;
						SAXBuilder builder = new SAXBuilder();
						Document doc;
						doc = builder.build(newFile);
						Element webAppNode = doc.getRootElement();
						for (Element element : webAppNode.getChildren()) {
							if (element.getName().equals("groupId")) {
								group = element.getValue();
							} else if (element.getName().equals("artifactId") && artifact.equals("")) {
								artifact = element.getValue();
							} else if (element.getName().equals("name") && name.equals("")) {
								name = element.getValue();
							} else if (element.getName().equals("description") && description.equals("")) {
								description = element.getValue();
							}
						}
					}

				}
				zipEntry = zis.getNextEntry();
			}
			zis.closeEntry();
			zis.close();

			if (numOfXmls > 1) {
				setting = "type2";
			} else {
				setting = "type1";
			}
			this.projectMetaInfo = new ProjectMetaInfo(group, artifact, name, description, setting);
			// System.out.println(this.projectMetaInfo);
			return new RequestRecord(projectMetaInfo, listOfEntityDetails);
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return null;
	}
	/**
	 * @author pravinp14
	 * Static inner class for getting all field and class information
	 */
	@SuppressWarnings(ProjectSpecificCreators.RAWTYPES)
	private static class ClassDtoDeclarationVisitor extends VoidVisitorAdapter {
		private String entityName = "";
		private String fieldName = "";
		private boolean isId = false;
		private String type = "";
		private boolean isUnique = false;
		private boolean isNull = false;
		private List<FieldRecord> listOfFields = new ArrayList<FieldRecord>();

		private void initializeValues(String name, String type, boolean isId, boolean isUnique, boolean isNull) {
			this.isId = isId;
			this.fieldName = name;
			this.type = type;
			this.isUnique = isUnique;
			this.isNull = isNull;
		}

		private void addFieldRecord() {
			this.listOfFields.add(new FieldRecord(this.fieldName, this.type, this.isId, this.isUnique, this.isNull));
		}

		/**
		 * 
		 */
		@Override
		public void visit(ClassOrInterfaceDeclaration n, Object arg) {
			Map<String, Object> map = (Map<String, Object>) arg;
			CallBackId backId = (CallBackId) map.get("CALL_ID");
			CallBackEntityDetails backEntityDetails = (CallBackEntityDetails) map.get("CALL_ENTITY");
			Long id = backId.getId();
			String entityName = n.getNameAsString();
			n.getFields().forEach(e -> {
				initializeValues("", "", false, false, false);
				NodeList<AnnotationExpr> list = e.getAnnotations();
				list.stream().forEach(ann -> {
					String annName = ann.getNameAsString();
					if (annName.equals(JakartaImports.ID)) {
						initializeValues("", "", true, false, false);
					}
					if (annName.contains(ProjectSpecificCreators.COLUMN_ANN)) {
						initializeValues("", "", true, true, false);
					}
				});
				FieldDeclaration declaration = e.asFieldDeclaration();
				initializeValues(
						declaration.getVariables().size() > 0 ? declaration.getVariables().get(0).getNameAsString()
								: "",
						e.getElementType().asString(), true, false, false);
				addFieldRecord();
			});
			backEntityDetails.setEntityDetails(new EntityDetails(id, entityName, listOfFields, entityName));
		}

	}

	public static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
		File destFile = new File(destinationDir, zipEntry.getName());

		String destDirPath = destinationDir.getCanonicalPath();
		String destFilePath = destFile.getCanonicalPath();

		if (!destFilePath.startsWith(destDirPath + File.separator)) {
			throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
		}

		return destFile;
	}

	public CompilationUnit getCompilationUnit(FileInputStream in) {

		// //System.out.println("In java file creater class - getCompilationUnit");
		ParseResult<CompilationUnit> cu1 = null;
		CompilationUnit cu = null;
		try {
			cu1 = new JavaParser().parse(in);
			cu = cu1.getResult().get();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return cu;
	}
}



