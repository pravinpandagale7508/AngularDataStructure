package com.birlasoft.project.dto;

import java.util.List;

public record RequestRecord(ProjectMetaInfo projectMetaInfo,List<EntityDetails> listOfEntities) {

}
