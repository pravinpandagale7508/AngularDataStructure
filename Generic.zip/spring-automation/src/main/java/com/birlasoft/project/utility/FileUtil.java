package com.birlasoft.project.utility;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.tomcat.util.http.fileupload.FileUtils;

public class FileUtil {

	private FileUtil() {
	}
	public static String getPackageNameByClassName(String className) {
		final Package[] packages = Package.getPackages();
	    String pkgName ="";
	    for (final Package p : packages) {
	        final String pack = p.getName();
	        final String tentative = pack + "." + className;
	        try {
	            Class.forName(tentative);
	        } catch (final ClassNotFoundException e) {
	            continue;
	        }
	        System.out.println(pack);
	        pkgName = pack;
	        break;
	    }
	    return pkgName;
	}
	public static String getOutPutDirectory(String dir, int maxNumOfProjectInDir) {
		String dirName = dir;
		List<File> files = null;
		try {
			files = getSubdirs(new File(System.getProperty("user.dir") + "/" + dir));
			String digits = dirName.replaceAll("[^0-9]", "");
			dirName = dirName.replace(digits, "");
			Integer i = 0;
			digits = digits.length() == 0 ? (0 + "") : (digits);
			i = Integer.valueOf(digits);
			if (files.size() >= maxNumOfProjectInDir) {
				dir = getOutPutDirectory(dirName + (i + 1), maxNumOfProjectInDir);
			}

		} catch (Exception e) {
			
		}
		return dir;

		// return dir;
	}

	public static List<File> getSubdirs(File file) {
		List<File> subdirs = Arrays.asList(file.listFiles(new FileFilter() {
			public boolean accept(File f) {
				return f.isDirectory();
			}
		}));
//		subdirs = new ArrayList<>(subdirs);
//		List<File> deepSubdirs = new ArrayList<>();
//		for (File subdir : subdirs) {
//			deepSubdirs.addAll(getSubdirs(subdir));
//		}
//		subdirs.addAll(deepSubdirs);
		return subdirs;
	}

	public static File createDirectory(String path) {
		File f = new File(path);
		try {
			FileUtils.forceMkdir(f);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return f;
	}

	public static File createNewFile(String path) {
		File f = null;
		try {
			f = new File(path);
			System.out.println(f.getName().split("\\.")[0]);
			f.createNewFile();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return f;
	}

	public static String getCurrentPackageName(String fileCanonicalPath) {
		// NEW: newly added code for replacing backward slashes
		String substringPath = fileCanonicalPath.substring(fileCanonicalPath.indexOf("java\\") + 5,
				fileCanonicalPath.length());

		if (substringPath.contains("\\")) {
			substringPath = substringPath.replace('\\', '.');
			return substringPath;
		}

		return fileCanonicalPath.substring(fileCanonicalPath.indexOf("java\\") + 5, fileCanonicalPath.length())
				.replace('/', '.');
	}
}