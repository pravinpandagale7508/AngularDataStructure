package com.birlasoft.project.services.specificationImpl;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.birlasoft.project.dto.AnnotationInfo;
import com.birlasoft.project.dto.ClassInfo;
import com.birlasoft.project.dto.ExtendInfo;
import com.birlasoft.project.dto.Field;
import com.birlasoft.project.services.specification.GeneralCreators;
import com.birlasoft.project.services.specification.JavaFileCreator;
import com.birlasoft.project.services.specification.OrgImports;
import com.birlasoft.project.services.specification.ProjectSpecificCreators;
import com.birlasoft.project.utility.FileUtil;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.MarkerAnnotationExpr;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

@Service
public class RepositoryCreator extends JavaFileCreator {

	@SuppressWarnings("unchecked")
	public CompilationUnit createRepo(File parentDir, ClassInfo repoInfo, String subFolderName) {
		CompilationUnit cu = null;
		try {
			File serviceDir = FileUtil.createDirectory(parentDir.getCanonicalPath() + File.separator + "com"
					+ File.separator + "birlasoft" + File.separator + subFolderName);

			cu = this.generateJava(parentDir, repoInfo, serviceDir, new ClassDeclarationVisitor());

		} catch (IOException e) {
			e.printStackTrace();
		}
		return cu;

	}
	
	
	@SuppressWarnings("rawtypes")
	private static class ClassDeclarationVisitor extends VoidVisitorAdapter {
		@Override
		public void visit(ClassOrInterfaceDeclaration n, Object arg) {

			ClassInfo repoInfo = (ClassInfo) arg;
			n.setName(repoInfo.getClassName());
			List<Field> listOfFields = repoInfo.getFields();
			for (Field field : listOfFields) {
				FieldDeclaration f = n.addField(field.type(), field.name(), Modifier.Keyword.PRIVATE);

				for (String ann : field.annotationList()) {
					f.addAnnotation(new MarkerAnnotationExpr(new Name(ann)));
				}
			}

			NodeList<AnnotationExpr> annotationExprList = new NodeList<>();

			List<AnnotationInfo> annotationInfos = repoInfo.getAnnotationList();
			List<String> annList = annotationInfos.stream().map(a -> {
				return a.annotationName();
			}).collect(Collectors.toList());

			for (String ann : annList) {
				MarkerAnnotationExpr markerAnnotationExpr = new MarkerAnnotationExpr(new Name(ann));
				annotationExprList.add(markerAnnotationExpr);
			}

			n.setAnnotations(annotationExprList);
			NodeList<ClassOrInterfaceType> classOrInterfaceTypes = new NodeList<>();

			repoInfo.getExtendInfoList().stream().map(e -> e.extendName()).forEach(s -> {
				ClassOrInterfaceType ct = new ClassOrInterfaceType().setName(new SimpleName(s));
				classOrInterfaceTypes.add(ct);
			});

			n.setExtendedTypes(classOrInterfaceTypes);
		}
	}

	@Override
	public CompilationUnit addClassInterface(CompilationUnit cu, ClassInfo clInfo) {
		cu.addInterface(clInfo.getClassName());
		return cu;
	}

}
